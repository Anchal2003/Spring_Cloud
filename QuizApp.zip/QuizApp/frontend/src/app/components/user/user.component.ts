import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { QuizService } from '../../services/quiz.service';
import { Quiz, QuizWithQuestions, QuizSubmission, QuizAttempt } from '../../models/quiz.model';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  quizzes: Quiz[] = [];
  attempts: QuizAttempt[] = [];
  selectedQuiz: QuizWithQuestions | null = null;
  currentQuestionIndex = 0;
  answers: { [questionId: number]: string } = {};
  showResult = false;
  result: QuizAttempt | null = null;
  view: 'quizzes' | 'attempts' = 'quizzes';
  timeRemaining = 0;
  timerInterval: any;

  constructor(
    public authService: AuthService,
    private quizService: QuizService
  ) {}

  ngOnInit(): void {
    this.loadQuizzes();
    this.loadAttempts();
  }

  loadQuizzes(): void {
    this.quizService.getAvailableQuizzes().subscribe(quizzes => this.quizzes = quizzes);
  }

  loadAttempts(): void {
    this.quizService.getMyAttempts().subscribe(attempts => this.attempts = attempts);
  }

  startQuiz(quizId: number): void {
    this.quizService.getQuizForUser(quizId).subscribe(quiz => {
      this.selectedQuiz = quiz;
      this.currentQuestionIndex = 0;
      this.answers = {};
      this.showResult = false;
      this.timeRemaining = quiz.timeLimit * 60;
      this.startTimer();
    });
  }

  startTimer(): void {
    this.timerInterval = setInterval(() => {
      this.timeRemaining--;
      if (this.timeRemaining <= 0) {
        this.submitQuiz();
      }
    }, 1000);
  }

  selectAnswer(questionId: number, answer: string): void {
    this.answers[questionId] = answer;
  }

  nextQuestion(): void {
    if (this.selectedQuiz && this.currentQuestionIndex < this.selectedQuiz.questions.length - 1) {
      this.currentQuestionIndex++;
    }
  }

  previousQuestion(): void {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
    }
  }

  submitQuiz(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    
    if (!this.selectedQuiz) return;

    const answersMap: { [key: string]: string } = {};
    Object.keys(this.answers).forEach(key => {
      answersMap[key] = this.answers[Number(key)];
    });

    const submission: QuizSubmission = { answers: answersMap };
    
    console.log('Submitting quiz:', this.selectedQuiz.id);
    console.log('Answers:', submission);
    
    this.quizService.submitQuiz(this.selectedQuiz.id, submission).subscribe({
      next: (result) => {
        console.log('Quiz result:', result);
        this.result = result;
        this.showResult = true;
        this.loadAttempts();
      },
      error: (err) => {
        console.error('Error submitting quiz:', err);
        alert('Failed to submit quiz. Please try again.');
      }
    });
  }

  closeQuiz(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    this.selectedQuiz = null;
    this.showResult = false;
    this.result = null;
  }

  switchView(view: 'quizzes' | 'attempts'): void {
    this.view = view;
  }

  getTimeFormatted(): string {
    const minutes = Math.floor(this.timeRemaining / 60);
    const seconds = this.timeRemaining % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }



  logout(): void {
    this.authService.logout();
  }
}

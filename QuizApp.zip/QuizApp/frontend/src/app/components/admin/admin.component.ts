import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { QuizService } from '../../services/quiz.service';
import { QuestionService } from '../../services/question.service';
import { Quiz, QuizDto, Question, QuestionDto } from '../../models/quiz.model';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  quizzes: Quiz[] = [];
  questions: Question[] = [];
  selectedQuizId: number | null = null;
  showQuizForm = false;
  showQuestionForm = false;
  editingQuiz: Quiz | null = null;
  editingQuestion: Question | null = null;

  quizForm: QuizDto = {
    title: '',
    description: '',
    duration: 30,
    totalMarks: 100,
    passingMarks: 40,
    active: true
  };

  questionForm: QuestionDto = {
    quizId: 0,
    questionText: '',
    option1: '',
    option2: '',
    option3: '',
    option4: '',
    correctAnswer: ''
  };

  constructor(
    public authService: AuthService,
    private quizService: QuizService,
    private questionService: QuestionService
  ) {}

  ngOnInit(): void {
    this.loadQuizzes();
  }

  loadQuizzes(): void {
    this.quizService.getAllQuizzes().subscribe(quizzes => this.quizzes = quizzes);
  }

  loadQuestions(quizId: number): void {
    this.selectedQuizId = quizId;
    this.questionService.getQuestionsByQuizId(quizId).subscribe(questions => this.questions = questions);
  }

  openQuizForm(quiz?: Quiz): void {
    if (quiz) {
      this.editingQuiz = quiz;
      this.quizForm = {
        title: quiz.title,
        description: quiz.description,
        duration: quiz.duration,
        totalMarks: quiz.totalMarks,
        passingMarks: quiz.passingMarks,
        active: quiz.active
      };
    } else {
      this.editingQuiz = null;
      this.resetQuizForm();
    }
    this.showQuizForm = true;
  }

  saveQuiz(): void {
    if (this.editingQuiz) {
      this.quizService.updateQuiz(this.editingQuiz.id, this.quizForm).subscribe(() => {
        this.loadQuizzes();
        this.closeQuizForm();
      });
    } else {
      this.quizService.createQuiz(this.quizForm).subscribe(() => {
        this.loadQuizzes();
        this.closeQuizForm();
      });
    }
  }

  deleteQuiz(id: number): void {
    if (confirm('Are you sure you want to delete this quiz?')) {
      this.quizService.deleteQuiz(id).subscribe(() => this.loadQuizzes());
    }
  }

  openQuestionForm(question?: Question): void {
    if (question) {
      this.editingQuestion = question;
      this.questionForm = {
        quizId: question.quizId,
        questionText: question.questionText,
        option1: question.option1,
        option2: question.option2,
        option3: question.option3,
        option4: question.option4,
        correctAnswer: question.correctAnswer || ''
      };
    } else {
      this.editingQuestion = null;
      this.resetQuestionForm();
      this.questionForm.quizId = this.selectedQuizId || 0;
    }
    this.showQuestionForm = true;
  }

  saveQuestion(): void {
    if (this.editingQuestion) {
      this.questionService.updateQuestion(this.editingQuestion.id, this.questionForm).subscribe(() => {
        if (this.selectedQuizId) this.loadQuestions(this.selectedQuizId);
        this.closeQuestionForm();
      });
    } else {
      this.questionService.createQuestion(this.questionForm).subscribe(() => {
        if (this.selectedQuizId) this.loadQuestions(this.selectedQuizId);
        this.closeQuestionForm();
      });
    }
  }

  deleteQuestion(id: number): void {
    if (confirm('Are you sure you want to delete this question?')) {
      this.questionService.deleteQuestion(id).subscribe(() => {
        if (this.selectedQuizId) this.loadQuestions(this.selectedQuizId);
      });
    }
  }

  closeQuizForm(): void {
    this.showQuizForm = false;
    this.editingQuiz = null;
    this.resetQuizForm();
  }

  closeQuestionForm(): void {
    this.showQuestionForm = false;
    this.editingQuestion = null;
    this.resetQuestionForm();
  }

  resetQuizForm(): void {
    this.quizForm = {
      title: '',
      description: '',
      duration: 30,
      totalMarks: 100,
      passingMarks: 40,
      active: true
    };
  }

  resetQuestionForm(): void {
    this.questionForm = {
      quizId: 0,
      questionText: '',
      option1: '',
      option2: '',
      option3: '',
      option4: '',
      correctAnswer: ''
    };
  }

  logout(): void {
    this.authService.logout();
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Question } from './quiz.service';

export interface QuestionDto {
  id?: number;
  questionText: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctAnswer: string;
  quizId: number;
}

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  private apiUrl = 'http://localhost:8080/questions';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  createQuestion(question: QuestionDto): Observable<Question> {
    return this.http.post<Question>(this.apiUrl, question, { headers: this.getHeaders() });
  }

  getQuestionsByQuiz(quizId: number): Observable<Question[]> {
    return this.http.get<Question[]>(`${this.apiUrl}/quiz/${quizId}`, { headers: this.getHeaders() });
  }

  getQuestionsForUser(quizId: number): Observable<QuestionDto[]> {
    return this.http.get<QuestionDto[]>(`${this.apiUrl}/quiz/${quizId}/user`, { headers: this.getHeaders() });
  }

  updateQuestion(id: number, question: QuestionDto): Observable<Question> {
    return this.http.put<Question>(`${this.apiUrl}/${id}`, question, { headers: this.getHeaders() });
  }

  deleteQuestion(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }
}
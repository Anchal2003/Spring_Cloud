import { Component, OnInit } from '@angular/core';
import { RouterLink, Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  imports: [RouterLink, FormsModule, CommonModule],
  template: `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-logo">
          <a routerLink="/home">
            <span class="logo-icon">🎯</span>
            <span class="logo-text">QuizApp</span>
          </a>
        </div>
        <ul class="nav-menu">
          <li class="nav-item">
            <a routerLink="/home" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a routerLink="/assessment" class="nav-link">Assessment</a>
          </li>
          <li class="nav-item">
            <a routerLink="/login" class="nav-link active">Login</a>
          </li>
          <li class="nav-item">
            <a routerLink="/signup" class="nav-link">Signup</a>
          </li>
        </ul>
      </div>
    </nav>
    
    <div class="login-container">
      <div class="background-animation">
        <div class="floating-shapes">
          <div class="shape shape-1"></div>
          <div class="shape shape-2"></div>
          <div class="shape shape-3"></div>
          <div class="shape shape-4"></div>
          <div class="shape shape-5"></div>
        </div>
      </div>
      
      <div class="login-content">
        <div class="login-card">
          <div class="card-header">
            <div class="logo-container">
              <div class="logo-3d">
                <span class="logo-icon">🎯</span>
              </div>
              <h1 class="app-title">QuizApp</h1>
            </div>
            <h2 class="welcome-text">Welcome Back!</h2>
            <p class="subtitle">Sign in to continue your learning journey</p>
          </div>
          
          <form (ngSubmit)="onLogin()" class="login-form">
            <div class="form-group">
              <div class="input-container">
                <div class="input-icon">👤</div>
                <input 
                  type="text" 
                  [(ngModel)]="username" 
                  name="username" 
                  placeholder="Username"
                  class="form-input"
                  required
                >
                <div class="input-border"></div>
              </div>
            </div>
            
            <div class="form-group">
              <div class="input-container">
                <div class="input-icon">🔒</div>
                <input 
                  type="password" 
                  [(ngModel)]="password" 
                  name="password" 
                  placeholder="Password"
                  class="form-input"
                  required
                >
                <div class="input-border"></div>
              </div>
            </div>
            
            <div *ngIf="errorMessage" class="error-message">
              <span class="error-icon">⚠️</span>
              {{ errorMessage }}
            </div>
            
            <button type="submit" [disabled]="isLoading" class="login-btn">
              <span *ngIf="!isLoading" class="btn-content">
                <span class="btn-icon">🚀</span>
                Sign In
              </span>
              <span *ngIf="isLoading" class="loading-content">
                <div class="spinner"></div>
                Signing In...
              </span>
            </button>
            
            <div class="form-footer">
              <p>Don't have an account? 
                <a routerLink="/signup" class="signup-link">Create one here</a>
              </p>
            </div>
          </form>
        </div>
        
        <div class="side-illustration">
          <div class="illustration-3d">
            <div class="quiz-elements">
              <div class="element element-1">📚</div>
              <div class="element element-2">🎓</div>
              <div class="element element-3">💡</div>
              <div class="element element-4">⭐</div>
              <div class="element element-5">🏆</div>
            </div>
            <div class="main-graphic">
              <div class="laptop-3d">
                <div class="laptop-screen">
                  <div class="screen-content">
                    <div class="quiz-preview">
                      <div class="question-bar"></div>
                      <div class="options">
                        <div class="option"></div>
                        <div class="option"></div>
                        <div class="option active"></div>
                        <div class="option"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="laptop-base"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    .navbar {
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.95), rgba(118, 75, 162, 0.95));
      backdrop-filter: blur(20px);
      padding: 1rem 0;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
      border-bottom: 1px solid rgba(255,255,255,0.1);
      animation: navSlideDown 0.8s ease-out;
    }
    
    @keyframes navSlideDown {
      from {
        transform: translateY(-100%);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    
    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2rem;
      position: relative;
    }
    
    .nav-container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
      transform: translateX(-100%);
      animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }
    
    .nav-logo a {
      color: #fff;
      font-size: 1.8rem;
      font-weight: 800;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      position: relative;
      z-index: 2;
    }
    
    .nav-logo a:hover {
      transform: scale(1.1) rotate(2deg);
      filter: drop-shadow(0 0 20px rgba(255,255,255,0.5));
    }
    
    .logo-icon {
      font-size: 2.2rem;
      animation: logoFloat 3s ease-in-out infinite;
      filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));
      transition: all 0.3s ease;
    }
    
    .nav-logo a:hover .logo-icon {
      animation: logoSpin 0.6s ease-in-out;
    }
    
    @keyframes logoFloat {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-8px) rotate(5deg); }
    }
    
    @keyframes logoSpin {
      0% { transform: rotate(0deg) scale(1); }
      50% { transform: rotate(180deg) scale(1.2); }
      100% { transform: rotate(360deg) scale(1); }
    }
    
    .logo-text {
      background: linear-gradient(45deg, #fff, #f0f8ff, #fff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      animation: textGlow 2s ease-in-out infinite alternate;
    }
    
    @keyframes textGlow {
      from { filter: drop-shadow(0 0 5px rgba(255,255,255,0.5)); }
      to { filter: drop-shadow(0 0 15px rgba(255,255,255,0.8)); }
    }
    
    .nav-menu {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
      gap: 0.5rem;
      position: relative;
      z-index: 2;
    }
    
    .nav-item {
      position: relative;
      overflow: hidden;
    }
    
    .nav-link {
      color: rgba(255, 255, 255, 0.9);
      text-decoration: none;
      padding: 0.75rem 1.5rem;
      border-radius: 25px;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      font-weight: 600;
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.1);
    }
    
    .nav-link::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s ease;
    }
    
    .nav-link:hover::before {
      left: 100%;
    }
    
    .nav-link::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 2px;
      background: linear-gradient(90deg, #fff, #f0f8ff);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }
    
    .nav-link:hover {
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      transform: translateY(-3px) scale(1.05);
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .nav-link:hover::after {
      width: 80%;
    }
    
    .nav-link.active {
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    .nav-link.active::after {
      width: 80%;
    }
    
    .login-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      position: relative;
      overflow-x: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .login-content {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 2;
    }
    
    .background-animation {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      z-index: 1;
    }
    
    .floating-shapes {
      position: relative;
      width: 100%;
      height: 100%;
    }
    
    .shape {
      position: absolute;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      animation: float 6s ease-in-out infinite;
    }
    
    .shape-1 {
      width: 80px;
      height: 80px;
      top: 20%;
      left: 10%;
      animation-delay: 0s;
    }
    
    .shape-2 {
      width: 120px;
      height: 120px;
      top: 60%;
      left: 80%;
      animation-delay: 2s;
    }
    
    .shape-3 {
      width: 60px;
      height: 60px;
      top: 80%;
      left: 20%;
      animation-delay: 4s;
    }
    
    .shape-4 {
      width: 100px;
      height: 100px;
      top: 10%;
      left: 70%;
      animation-delay: 1s;
    }
    
    .shape-5 {
      width: 40px;
      height: 40px;
      top: 40%;
      left: 5%;
      animation-delay: 3s;
    }
    
    @keyframes float {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-20px) rotate(180deg); }
    }
    
    .login-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4rem;
      max-width: 1200px;
      width: 100%;
      padding: 2rem;
      position: relative;
      z-index: 2;
    }
    
    .login-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 3rem;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      transform: perspective(1000px) rotateY(-5deg);
      transition: all 0.3s ease;
      animation: slideInLeft 0.8s ease-out;
    }
    
    .login-card:hover {
      transform: perspective(1000px) rotateY(0deg) translateY(-5px);
      box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
    }
    
    @keyframes slideInLeft {
      from {
        opacity: 0;
        transform: perspective(1000px) rotateY(-15deg) translateX(-50px);
      }
      to {
        opacity: 1;
        transform: perspective(1000px) rotateY(-5deg) translateX(0);
      }
    }
    
    .card-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    
    .logo-container {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      margin-bottom: 1rem;
    }
    
    .logo-3d {
      width: 60px;
      height: 60px;
      background: linear-gradient(45deg, #667eea, #764ba2);
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      transform: perspective(100px) rotateX(15deg);
      box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
      animation: logoFloat 3s ease-in-out infinite;
    }
    
    @keyframes logoFloat {
      0%, 100% { transform: perspective(100px) rotateX(15deg) translateY(0px); }
      50% { transform: perspective(100px) rotateX(15deg) translateY(-5px); }
    }
    
    .logo-icon {
      font-size: 2rem;
      filter: drop-shadow(2px 2px 4px rgba(0,0,0,0.3));
    }
    
    .app-title {
      font-size: 2.5rem;
      font-weight: 700;
      background: linear-gradient(45deg, #667eea, #764ba2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .welcome-text {
      font-size: 1.8rem;
      color: #2c3e50;
      margin-bottom: 0.5rem;
      font-weight: 600;
    }
    
    .subtitle {
      color: #7f8c8d;
      font-size: 1rem;
    }
    
    .login-form {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }
    
    .form-group {
      position: relative;
    }
    
    .input-container {
      position: relative;
      display: flex;
      align-items: center;
    }
    
    .input-icon {
      position: absolute;
      left: 1rem;
      font-size: 1.2rem;
      z-index: 2;
      transition: all 0.3s ease;
    }
    
    .form-input {
      width: 100%;
      padding: 1rem 1rem 1rem 3rem;
      border: 2px solid #e9ecef;
      border-radius: 12px;
      font-size: 1rem;
      background: rgba(248, 249, 250, 0.8);
      transition: all 0.3s ease;
      position: relative;
      z-index: 1;
    }
    
    .form-input:focus {
      outline: none;
      border-color: #667eea;
      background: white;
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
    }
    
    .form-input:focus + .input-border {
      transform: scaleX(1);
    }
    
    .input-border {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 2px;
      background: linear-gradient(45deg, #667eea, #764ba2);
      transform: scaleX(0);
      transition: transform 0.3s ease;
      border-radius: 1px;
    }
    
    .error-message {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #e74c3c;
      font-size: 0.9rem;
      padding: 0.75rem 1rem;
      background: rgba(231, 76, 60, 0.1);
      border-radius: 8px;
      border-left: 4px solid #e74c3c;
      animation: shake 0.5s ease-in-out;
    }
    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }
    
    .login-btn {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 12px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      transform: perspective(100px) rotateX(5deg);
    }
    
    .login-btn:hover:not(:disabled) {
      transform: perspective(100px) rotateX(0deg) translateY(-3px);
      box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
    }
    
    .login-btn:active {
      transform: perspective(100px) rotateX(5deg) translateY(0px);
    }
    
    .login-btn:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }
    
    .btn-content, .loading-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
    }
    
    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top: 2px solid white;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    .form-footer {
      text-align: center;
      margin-top: 1rem;
    }
    
    .signup-link {
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    
    .signup-link:hover {
      color: #764ba2;
      text-decoration: underline;
    }
    
    .side-illustration {
      display: flex;
      align-items: center;
      justify-content: center;
      animation: slideInRight 0.8s ease-out;
    }
    
    @keyframes slideInRight {
      from {
        opacity: 0;
        transform: translateX(50px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    
    .illustration-3d {
      position: relative;
      width: 400px;
      height: 400px;
    }
    
    .quiz-elements {
      position: absolute;
      width: 100%;
      height: 100%;
    }
    
    .element {
      position: absolute;
      font-size: 2rem;
      animation: elementFloat 4s ease-in-out infinite;
      filter: drop-shadow(0 4px 8px rgba(0,0,0,0.2));
    }
    
    .element-1 {
      top: 10%;
      left: 20%;
      animation-delay: 0s;
    }
    
    .element-2 {
      top: 20%;
      right: 10%;
      animation-delay: 1s;
    }
    
    .element-3 {
      bottom: 30%;
      left: 10%;
      animation-delay: 2s;
    }
    
    .element-4 {
      top: 60%;
      right: 20%;
      animation-delay: 3s;
    }
    
    .element-5 {
      bottom: 10%;
      left: 40%;
      animation-delay: 4s;
    }
    
    @keyframes elementFloat {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-15px) rotate(10deg); }
    }
    
    .main-graphic {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    
    .laptop-3d {
      position: relative;
      transform: perspective(800px) rotateX(15deg) rotateY(-15deg);
      animation: laptopFloat 6s ease-in-out infinite;
    }
    
    @keyframes laptopFloat {
      0%, 100% { transform: perspective(800px) rotateX(15deg) rotateY(-15deg) translateY(0px); }
      50% { transform: perspective(800px) rotateX(15deg) rotateY(-15deg) translateY(-10px); }
    }
    
    .laptop-screen {
      width: 200px;
      height: 130px;
      background: linear-gradient(145deg, #2c3e50, #34495e);
      border-radius: 8px 8px 0 0;
      border: 3px solid #1a252f;
      position: relative;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }
    
    .screen-content {
      position: absolute;
      top: 8px;
      left: 8px;
      right: 8px;
      bottom: 8px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      border-radius: 4px;
      padding: 1rem;
    }
    
    .quiz-preview {
      height: 100%;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }
    
    .question-bar {
      height: 20px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 4px;
      animation: pulse 2s ease-in-out infinite;
    }
    
    .options {
      display: flex;
      flex-direction: column;
      gap: 0.3rem;
      flex: 1;
    }
    
    .option {
      height: 15px;
      background: rgba(255, 255, 255, 0.6);
      border-radius: 3px;
      transition: all 0.3s ease;
    }
    
    .option.active {
      background: rgba(255, 255, 255, 0.9);
      transform: scale(1.05);
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 0.6; }
      50% { opacity: 1; }
    }
    
    .laptop-base {
      width: 220px;
      height: 15px;
      background: linear-gradient(145deg, #bdc3c7, #95a5a6);
      border-radius: 0 0 12px 12px;
      margin-top: -2px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    @media (max-width: 768px) {
      .nav-container {
        padding: 0 1rem;
      }
      
      .nav-logo a {
        font-size: 1.5rem;
      }
      
      .logo-icon {
        font-size: 1.8rem;
      }
      
      .nav-menu {
        display: none;
      }
      
      .login-content {
        grid-template-columns: 1fr;
        gap: 2rem;
        padding: 1rem;
      }
      
      .login-card {
        transform: none;
        padding: 2rem;
      }
      
      .login-card:hover {
        transform: translateY(-5px);
      }
      
      .side-illustration {
        order: -1;
      }
      
      .illustration-3d {
        width: 300px;
        height: 300px;
      }
      
      .app-title {
        font-size: 2rem;
      }
      
      .welcome-text {
        font-size: 1.5rem;
      }
    }
  `]
})
export class LoginComponent implements OnInit {
  showPassword = false;
  username = '';
  password = '';
  errorMessage = '';
  isLoading = false;
  returnUrl = '';

  constructor(
    private authService: AuthService, 
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['returnUrl']) {
        this.returnUrl = params['returnUrl'];
      }
    });
  }

  onLogin() {
    if (!this.username || !this.password) {
      this.errorMessage = 'Please fill in all fields';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const loginData = {
      username: this.username,
      password: this.password
    };

    this.authService.login(loginData).subscribe({
      next: (response) => {
        if (this.returnUrl) {
          this.router.navigateByUrl(this.returnUrl);
          return;
        }
        
        const role = this.authService.getUserRole();
        if (role === 'ADMIN') {
          this.router.navigate(['/admin-dashboard']);
        } else {
          this.router.navigate(['/user-dashboard']);
        }
      },
      error: (error) => {
        this.errorMessage = 'Invalid username or password';
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
}
export interface AuthRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email: string;
  fullName: string;
  phone: string;
}

export interface AuthResponse {
  token: string;
}

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone: string;
  role: string;
  createdAt: string;
}

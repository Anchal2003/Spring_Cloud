import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-assessment',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="assessment-container">
      <div class="background-animation">
        <div class="floating-shapes">
          <div class="shape shape-1"></div>
          <div class="shape shape-2"></div>
          <div class="shape shape-3"></div>
          <div class="shape shape-4"></div>
          <div class="shape shape-5"></div>
          <div class="shape shape-6"></div>
        </div>
      </div>
      
      <nav class="navbar">
        <div class="nav-container">
          <div class="nav-logo">
            <a routerLink="/home">
              <span class="logo-icon">🎯</span>
              <span class="logo-text">QuizApp</span>
            </a>
          </div>
          <ul class="nav-menu">
            <li class="nav-item">
              <a routerLink="/home" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
              <a routerLink="/assessment" class="nav-link active">Assessment</a>
            </li>
            <li class="nav-item">
              <a routerLink="/login" class="nav-link">Login</a>
            </li>
            <li class="nav-item">
              <a routerLink="/signup" class="nav-link">Signup</a>
            </li>
          </ul>
        </div>
      </nav>

      <main class="assessment-content">
        <div class="hero-section">
          <div class="hero-3d-elements">
            <div class="floating-icons">
              <div class="icon icon-1">📚</div>
              <div class="icon icon-2">🎓</div>
              <div class="icon icon-3">💡</div>
              <div class="icon icon-4">⭐</div>
              <div class="icon icon-5">🏆</div>
              <div class="icon icon-6">🚀</div>
            </div>
            <div class="hero-graphic">
              <div class="quiz-stack-3d">
                <div class="quiz-paper quiz-paper-1">
                  <div class="paper-content">
                    <div class="question-line"></div>
                    <div class="question-line short"></div>
                    <div class="options-preview">
                      <div class="option-dot"></div>
                      <div class="option-dot"></div>
                      <div class="option-dot active"></div>
                      <div class="option-dot"></div>
                    </div>
                  </div>
                </div>
                <div class="quiz-paper quiz-paper-2">
                  <div class="paper-content">
                    <div class="question-line"></div>
                    <div class="question-line short"></div>
                    <div class="options-preview">
                      <div class="option-dot"></div>
                      <div class="option-dot active"></div>
                      <div class="option-dot"></div>
                      <div class="option-dot"></div>
                    </div>
                  </div>
                </div>
                <div class="quiz-paper quiz-paper-3">
                  <div class="paper-content">
                    <div class="question-line"></div>
                    <div class="question-line short"></div>
                    <div class="options-preview">
                      <div class="option-dot active"></div>
                      <div class="option-dot"></div>
                      <div class="option-dot"></div>
                      <div class="option-dot"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="hero-text">
            <h1 class="hero-title">Available Assessments</h1>
            <p class="hero-subtitle">Choose from our collection of quizzes to test your knowledge and enhance your learning journey</p>
          </div>
        </div>

        <div class="quizzes-section">
          <div *ngIf="loading" class="loading-state">
            <div class="loading-animation">
              <div class="loading-spinner"></div>
              <div class="loading-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            <h2>Loading Assessments...</h2>
            <p>Please wait while we fetch the latest quizzes for you</p>
          </div>

          <div *ngIf="error" class="error-state">
            <div class="error-icon">⚠️</div>
            <h2>Unable to Load Assessments</h2>
            <p>{{ error }}</p>
            <button (click)="loadPublicQuizzes()" class="retry-btn">
              <span class="btn-icon">🔄</span>
              Try Again
            </button>
          </div>

          <div *ngIf="!loading && !error" class="quiz-grid">
            <div *ngFor="let quiz of quizzes; let i = index" 
                 class="quiz-card" 
                 [style.animation-delay.ms]="i * 150">
              <div class="card-glow"></div>
              <div class="card-header">
                <div class="quiz-icon">📋</div>
                <div class="difficulty-badge">{{ getDifficulty(quiz) }}</div>
              </div>
              <div class="card-content">
                <h3 class="quiz-title">{{ quiz.title }}</h3>
                <p class="quiz-description">{{ quiz.description }}</p>
                <div class="quiz-meta">
                  <div class="meta-item" *ngIf="quiz.timeLimit">
                    <span class="meta-icon">⏱️</span>
                    <span class="meta-text">{{ quiz.timeLimit }} minutes</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-icon">📊</span>
                    <span class="meta-text">{{ getQuestionCount(quiz) }} questions</span>
                  </div>
                </div>
              </div>
              <div class="card-footer">
                <button (click)="startQuiz(quiz)" class="start-btn">
                  <span class="btn-content">
                    <span class="btn-icon">🚀</span>
                    <span class="btn-text">Start Assessment</span>
                  </span>
                  <div class="btn-ripple"></div>
                </button>
              </div>
            </div>
          </div>

          <div *ngIf="!loading && !error && quizzes.length === 0" class="empty-state">
            <div class="empty-animation">
              <div class="empty-icon">📋</div>
              <div class="empty-particles">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            <h2>No Assessments Available</h2>
            <p>We're working on adding new quizzes. Please check back later!</p>
            <button (click)="loadPublicQuizzes()" class="refresh-btn">
              <span class="btn-icon">🔄</span>
              Refresh
            </button>
          </div>
        </div>
      </main>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    .assessment-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      position: relative;
      overflow-x: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .background-animation {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    }
    
    .floating-shapes {
      position: relative;
      width: 100%;
      height: 100%;
    }
    
    .shape {
      position: absolute;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      animation: floatShape 8s ease-in-out infinite;
    }
    
    .shape-1 { width: 80px; height: 80px; top: 10%; left: 5%; animation-delay: 0s; }
    .shape-2 { width: 120px; height: 120px; top: 70%; left: 85%; animation-delay: 2s; }
    .shape-3 { width: 60px; height: 60px; top: 30%; left: 90%; animation-delay: 4s; }
    .shape-4 { width: 100px; height: 100px; top: 80%; left: 10%; animation-delay: 1s; }
    .shape-5 { width: 40px; height: 40px; top: 50%; left: 3%; animation-delay: 3s; }
    .shape-6 { width: 90px; height: 90px; top: 20%; left: 80%; animation-delay: 5s; }
    
    @keyframes floatShape {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-30px) rotate(180deg); }
    }
    
    .navbar {
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.95), rgba(118, 75, 162, 0.95));
      backdrop-filter: blur(20px);
      padding: 1rem 0;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
      border-bottom: 1px solid rgba(255,255,255,0.1);
      animation: navSlideDown 0.8s ease-out;
    }
    
    @keyframes navSlideDown {
      from { transform: translateY(-100%); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    
    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2rem;
    }
    
    .nav-logo a {
      color: #fff;
      font-size: 1.8rem;
      font-weight: 800;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transition: all 0.4s ease;
    }
    
    .nav-logo a:hover {
      transform: scale(1.1);
      filter: drop-shadow(0 0 20px rgba(255,255,255,0.5));
    }
    
    .logo-icon {
      font-size: 2.2rem;
      animation: logoFloat 3s ease-in-out infinite;
    }
    
    @keyframes logoFloat {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-8px) rotate(5deg); }
    }
    
    .nav-menu {
      display: flex;
      list-style: none;
      gap: 0.5rem;
    }
    
    .nav-link {
      color: rgba(255, 255, 255, 0.9);
      text-decoration: none;
      padding: 0.75rem 1.5rem;
      border-radius: 25px;
      transition: all 0.4s ease;
      font-weight: 600;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.1);
    }
    
    .nav-link:hover, .nav-link.active {
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    .assessment-content {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
      position: relative;
      z-index: 2;
    }
    
    .hero-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4rem;
      align-items: center;
      margin-bottom: 4rem;
      min-height: 400px;
    }
    
    .hero-3d-elements {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .floating-icons {
      position: absolute;
      width: 100%;
      height: 100%;
    }
    
    .icon {
      position: absolute;
      font-size: 2.5rem;
      animation: iconFloat 4s ease-in-out infinite;
      filter: drop-shadow(0 4px 8px rgba(0,0,0,0.2));
    }
    
    .icon-1 { top: 10%; left: 10%; animation-delay: 0s; }
    .icon-2 { top: 20%; right: 5%; animation-delay: 1s; }
    .icon-3 { bottom: 30%; left: 5%; animation-delay: 2s; }
    .icon-4 { top: 60%; right: 10%; animation-delay: 3s; }
    .icon-5 { bottom: 10%; left: 30%; animation-delay: 4s; }
    .icon-6 { top: 40%; right: 30%; animation-delay: 2.5s; }
    
    @keyframes iconFloat {
      0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); }
      50% { transform: translateY(-15px) rotate(10deg) scale(1.1); }
    }
    
    .quiz-stack-3d {
      position: relative;
      transform: perspective(1000px) rotateX(10deg) rotateY(-10deg);
      animation: stackFloat 6s ease-in-out infinite;
    }
    
    @keyframes stackFloat {
      0%, 100% { transform: perspective(1000px) rotateX(10deg) rotateY(-10deg) translateY(0px); }
      50% { transform: perspective(1000px) rotateX(10deg) rotateY(-10deg) translateY(-10px); }
    }
    
    .quiz-paper {
      width: 250px;
      height: 320px;
      background: white;
      border-radius: 12px;
      position: absolute;
      box-shadow: 0 15px 40px rgba(0,0,0,0.2);
      border: 1px solid rgba(0,0,0,0.1);
    }
    
    .quiz-paper-1 {
      z-index: 3;
      transform: translateZ(20px);
    }
    
    .quiz-paper-2 {
      z-index: 2;
      transform: translateZ(10px) translateX(10px) translateY(10px);
      opacity: 0.9;
    }
    
    .quiz-paper-3 {
      z-index: 1;
      transform: translateZ(0px) translateX(20px) translateY(20px);
      opacity: 0.8;
    }
    
    .paper-content {
      padding: 2rem;
      height: 100%;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    
    .question-line {
      height: 12px;
      background: linear-gradient(90deg, #667eea, #764ba2);
      border-radius: 6px;
      animation: pulse 2s ease-in-out infinite;
    }
    
    .question-line.short {
      width: 70%;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 0.6; }
      50% { opacity: 1; }
    }
    
    .options-preview {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-top: 1rem;
    }
    
    .option-dot {
      width: 100%;
      height: 8px;
      background: #e9ecef;
      border-radius: 4px;
      transition: all 0.3s ease;
    }
    
    .option-dot.active {
      background: linear-gradient(90deg, #28a745, #20c997);
      transform: scale(1.05);
    }
    
    .hero-text {
      text-align: left;
      color: white;
      animation: slideInRight 0.8s ease-out;
    }
    
    @keyframes slideInRight {
      from { opacity: 0; transform: translateX(50px); }
      to { opacity: 1; transform: translateX(0); }
    }
    
    .hero-title {
      font-size: 3.5rem;
      font-weight: 800;
      margin-bottom: 1rem;
      background: linear-gradient(45deg, #fff, #f0f8ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      line-height: 1.2;
    }
    
    .hero-subtitle {
      font-size: 1.3rem;
      opacity: 0.9;
      line-height: 1.6;
    }
    
    .quizzes-section {
      position: relative;
      z-index: 2;
    }
    
    .loading-state, .error-state, .empty-state {
      text-align: center;
      padding: 4rem 2rem;
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      color: #2c3e50;
    }
    
    .loading-animation {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .loading-spinner {
      width: 60px;
      height: 60px;
      border: 4px solid rgba(102, 126, 234, 0.2);
      border-top: 4px solid #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    .loading-dots {
      display: flex;
      gap: 0.5rem;
    }
    
    .loading-dots span {
      width: 8px;
      height: 8px;
      background: #667eea;
      border-radius: 50%;
      animation: bounce 1.4s ease-in-out infinite both;
    }
    
    .loading-dots span:nth-child(1) { animation-delay: -0.32s; }
    .loading-dots span:nth-child(2) { animation-delay: -0.16s; }
    
    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }
    
    .error-icon, .empty-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
    }
    
    .retry-btn, .refresh-btn {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 25px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin: 1rem auto 0;
    }
    
    .retry-btn:hover, .refresh-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
    }
    
    .quiz-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
      gap: 2rem;
    }
    
    .quiz-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 0;
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      position: relative;
      overflow: hidden;
      animation: cardSlideUp 0.6s ease-out both;
    }
    
    @keyframes cardSlideUp {
      from {
        opacity: 0;
        transform: translateY(50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .quiz-card:hover {
      transform: translateY(-10px) scale(1.02);
      box-shadow: 0 25px 60px rgba(0,0,0,0.15);
    }
    
    .card-glow {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(45deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    
    .quiz-card:hover .card-glow {
      opacity: 1;
    }
    
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem 1.5rem 0;
    }
    
    .quiz-icon {
      font-size: 2.5rem;
      animation: iconBounce 2s ease-in-out infinite;
    }
    
    @keyframes iconBounce {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-5px); }
    }
    
    .difficulty-badge {
      background: linear-gradient(45deg, #28a745, #20c997);
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 15px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .card-content {
      padding: 1.5rem;
    }
    
    .quiz-title {
      font-size: 1.4rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 0.75rem;
      line-height: 1.3;
    }
    
    .quiz-description {
      color: #7f8c8d;
      line-height: 1.6;
      margin-bottom: 1.5rem;
    }
    
    .quiz-meta {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }
    
    .meta-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(102, 126, 234, 0.1);
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.9rem;
    }
    
    .card-footer {
      padding: 0 1.5rem 1.5rem;
    }
    
    .start-btn {
      width: 100%;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 15px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    
    .start-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
    }
    
    .btn-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      position: relative;
      z-index: 2;
    }
    
    .btn-ripple {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background: rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: all 0.6s ease;
    }
    
    .start-btn:active .btn-ripple {
      width: 300px;
      height: 300px;
    }
    
    @media (max-width: 768px) {
      .nav-menu { display: none; }
      .hero-section {
        grid-template-columns: 1fr;
        gap: 2rem;
        text-align: center;
      }
      .hero-title { font-size: 2.5rem; }
      .quiz-grid { grid-template-columns: 1fr; }
      .assessment-content { padding: 1rem; }
    }
  `]
})
export class AssessmentComponent implements OnInit {
  
  getDifficulty(quiz: any): string {
    const timeLimit = quiz.timeLimit || 15;
    if (timeLimit <= 10) return 'Easy';
    if (timeLimit <= 20) return 'Medium';
    return 'Hard';
  }
  
  getQuestionCount(quiz: any): number {
    return Math.floor(Math.random() * 15) + 5; // Mock question count
  }
  quizzes: any[] = [];
  loading = true;
  error = '';

  constructor(
    private router: Router,
    private http: HttpClient,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loadPublicQuizzes();
  }

  loadPublicQuizzes() {
    // Load quizzes without authentication
    this.http.get<any[]>('http://localhost:8080/public/quizzes').subscribe({
      next: (quizzes) => {
        this.quizzes = quizzes;
        this.loading = false;
      },
      error: (error) => {
        console.error('Failed to load public quizzes:', error);
        // Fallback to sample quizzes if API fails
        this.quizzes = [
          {
            id: 1,
            title: 'General Knowledge Quiz',
            description: 'Test your general knowledge with this comprehensive quiz covering various topics.',
            timeLimit: 15
          },
          {
            id: 2,
            title: 'Science & Technology',
            description: 'Challenge yourself with questions about science, technology, and innovation.',
            timeLimit: 20
          },
          {
            id: 3,
            title: 'History & Geography',
            description: 'Explore your knowledge of world history and geography.',
            timeLimit: 25
          }
        ];
        this.loading = false;
      }
    });
  }

  startQuiz(quiz: any) {
    // Check if user is logged in
    if (this.authService.isAuthenticated()) {
      // User is logged in, go to quiz
      this.router.navigate(['/quiz', quiz.id]);
    } else {
      // User not logged in, redirect to login with return URL
      this.router.navigate(['/login'], { 
        queryParams: { returnUrl: `/quiz/${quiz.id}` }
      });
    }
  }
}
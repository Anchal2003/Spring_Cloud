import { Component, OnInit } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, UserProfile } from '../services/auth.service';

@Component({
  selector: 'app-profile',
  imports: [RouterLink, CommonModule],
  template: `
    <div class="profile-page">
      <nav class="navbar">
        <a routerLink="/home" class="logo">QuizApp</a>
        <div>
          <button (click)="goBack()">Back</button>
          <button (click)="logout()">Logout</button>
        </div>
      </nav>
      <main>
        <div *ngIf="isLoading">Loading...</div>
        <div *ngIf="!isLoading && profile">
          <div class="profile-header">
            <div class="avatar">{{ getInitials() }}</div>
            <div>
              <h1>{{ profile.fullName }}</h1>
              <p>{{ profile.username }}</p>
              <span>{{ profile.role }}</span>
            </div>
          </div>
          <div class="card">
            <h3>Contact</h3>
            <p>Email: {{ profile.email }}</p>
            <p>Phone: {{ profile.phone || 'Not provided' }}</p>
          </div>
        </div>
      </main>
    </div>
  `,
  styles: [`
    .profile-page {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 1rem;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background: rgba(255,255,255,0.1);
      border-radius: 10px;
      margin-bottom: 2rem;
    }
    .logo {
      color: white;
      text-decoration: none;
      font-size: 1.5rem;
      font-weight: bold;
    }
    button {
      padding: 0.5rem 1rem;
      margin: 0 0.5rem;
      border: none;
      border-radius: 5px;
      background: rgba(255,255,255,0.2);
      color: white;
      cursor: pointer;
    }
    .profile-header {
      display: flex;
      align-items: center;
      gap: 2rem;
      background: white;
      padding: 2rem;
      border-radius: 10px;
      margin-bottom: 2rem;
    }
    .avatar {
      width: 80px;
      height: 80px;
      background: #667eea;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 2rem;
      font-weight: bold;
    }
    .card {
      background: white;
      padding: 2rem;
      border-radius: 10px;
    }
    h1, h3 {
      margin: 0 0 1rem 0;
    }
    p {
      margin: 0.5rem 0;
    }
  `]
})
export class ProfileComponent implements OnInit {
  profile: UserProfile | null = null;
  isLoading = true;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadProfile();
  }

  loadProfile() {
    this.authService.getProfile().subscribe({
      next: (profile) => {
        this.profile = profile;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  getInitials(): string {
    if (!this.profile?.fullName) return 'U';
    return this.profile.fullName.split(' ').map(n => n[0]).join('').toUpperCase();
  }

  goBack() {
    const role = this.authService.getUserRole();
    if (role === 'ADMIN') {
      this.router.navigate(['/admin-dashboard']);
    } else {
      this.router.navigate(['/user-dashboard']);
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/home']);
  }
}
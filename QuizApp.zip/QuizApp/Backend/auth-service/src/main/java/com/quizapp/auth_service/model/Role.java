package com.quizapp.auth_service.model;

public enum Role {

    USER,
    ADMIN

}

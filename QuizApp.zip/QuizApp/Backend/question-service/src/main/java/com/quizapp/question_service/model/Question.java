package com.quizapp.question_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "questions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Question text must not be blank")
    private String questionText;

    @NotBlank(message = "Option1 must not be blank")
    private String option1;

    @NotBlank(message = "Option2 must not be blank")
    private String option2;

    @NotBlank(message = "Option3 must not be blank")
    private String option3;

    @NotBlank(message = "Option4 must not be blank")
    private String option4;

    @NotBlank(message = "Correct answer must not be blank")
    private String correctAnswer;

    @NotNull(message = "QuizId must not be null")
    private Long quizId;

}


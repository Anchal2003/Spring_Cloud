package com.quizapp.question_service.service;

import com.quizapp.question_service.dto.QuestionDto;
import com.quizapp.question_service.exception.ResourceNotFoundException;
import com.quizapp.question_service.model.Question;
import com.quizapp.question_service.repository.QuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuestionService {

    private final QuestionRepository questionRepo;

    public Question createQuestion(QuestionDto dto) {
        Question question = new Question();
        question.setQuestionText(dto.getQuestionText());
        question.setOption1(dto.getOption1());
        question.setOption2(dto.getOption2());
        question.setOption3(dto.getOption3());
        question.setOption4(dto.getOption4());
        question.setCorrectAnswer(dto.getCorrectAnswer());
        question.setQuizId(dto.getQuizId());
        return questionRepo.save(question);
    }

    public List<Question> getQuestionsByQuizId(Long quizId) {
        return questionRepo.findByQuizId(quizId);
    }

    public Question updateQuestion(Long id, QuestionDto dto) {
        Question question = questionRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Question not found"));
        question.setQuestionText(dto.getQuestionText());
        question.setOption1(dto.getOption1());
        question.setOption2(dto.getOption2());
        question.setOption3(dto.getOption3());
        question.setOption4(dto.getOption4());
        question.setCorrectAnswer(dto.getCorrectAnswer());
        return questionRepo.save(question);
    }

    public void deleteQuestion(Long id) {
        questionRepo.deleteById(id);
    }

    public List<Question> getQuestionsForUser(Long quizId) {
        return questionRepo.findByQuizId(quizId);
    }
}

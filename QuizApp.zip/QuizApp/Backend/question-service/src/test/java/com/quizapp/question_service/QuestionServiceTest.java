package com.quizapp.question_service;

import com.quizapp.question_service.dto.QuestionDto;
import com.quizapp.question_service.model.Question;
import com.quizapp.question_service.repository.QuestionRepository;
import com.quizapp.question_service.service.QuestionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class QuestionServiceTest {

    private QuestionRepository questionRepo;
    private QuestionService questionService;

    @BeforeEach
    void setUp() {
        questionRepo = mock(QuestionRepository.class);
        questionService = new QuestionService(questionRepo);
    }

    private QuestionDto getSampleDto() {
        QuestionDto dto = new QuestionDto();
        dto.setQuestionText("What is Java?");
        dto.setOption1("Language");
        dto.setOption2("Coffee");
        dto.setOption3("Island");
        dto.setOption4("Car");
        dto.setCorrectAnswer("Language");
        dto.setQuizId(1L);
        return dto;
    }

    @Test
    void testCreateQuestion() {
        QuestionDto dto = getSampleDto();
        Question savedQuestion = new Question();
        savedQuestion.setId(1L);
        savedQuestion.setQuestionText(dto.getQuestionText());

        when(questionRepo.save(any(Question.class))).thenReturn(savedQuestion);

        Question result = questionService.createQuestion(dto);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("What is Java?", result.getQuestionText());

        // Verify repository interaction
        verify(questionRepo, times(1)).save(any(Question.class));
    }

    @Test
    void testGetQuestionsByQuizId() {
        Question q1 = new Question();
        q1.setId(1L);
        q1.setQuizId(1L);

        when(questionRepo.findByQuizId(1L)).thenReturn(Arrays.asList(q1));

        List<Question> result = questionService.getQuestionsByQuizId(1L);

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getQuizId());
        verify(questionRepo, times(1)).findByQuizId(1L);
    }

    @Test
    void testUpdateQuestion() {
        QuestionDto dto = getSampleDto();
        Question existing = new Question();
        existing.setId(1L);
        existing.setQuestionText("Old Question");

        when(questionRepo.findById(1L)).thenReturn(Optional.of(existing));
        when(questionRepo.save(any(Question.class))).thenReturn(existing);

        Question updated = questionService.updateQuestion(1L, dto);

        assertEquals("What is Java?", updated.getQuestionText());
        assertEquals("Language", updated.getCorrectAnswer());

        verify(questionRepo).findById(1L);
        verify(questionRepo).save(existing);
    }

    @Test
    void testUpdateQuestion_NotFound() {
        when(questionRepo.findById(99L)).thenReturn(Optional.empty());

        QuestionDto dto = getSampleDto();

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> questionService.updateQuestion(99L, dto));

        assertEquals("Question not found", ex.getMessage());
    }

    @Test
    void testDeleteQuestion() {
        questionService.deleteQuestion(1L);
        verify(questionRepo, times(1)).deleteById(1L);
    }

    @Test
    void testGetQuestionsForUser() {
        Question q1 = new Question();
        q1.setId(1L);
        q1.setQuizId(2L);

        when(questionRepo.findByQuizId(2L)).thenReturn(Arrays.asList(q1));

        List<Question> result = questionService.getQuestionsForUser(2L);

        assertEquals(1, result.size());
        assertEquals(2L, result.get(0).getQuizId());
        verify(questionRepo, times(1)).findByQuizId(2L);
    }
}
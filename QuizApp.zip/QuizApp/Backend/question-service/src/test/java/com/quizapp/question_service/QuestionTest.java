package com.quizapp.question_service;

import com.quizapp.question_service.model.Question;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class QuestionTest {

    private static Validator validator;

    @BeforeAll
    static void setupValidator() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void testAllArgsConstructorAndGetters() {
        Question q = new Question(
                1L,
                "What is Java?",
                "Language",
                "Animal",
                "Island",
                "Coffee",
                "Language",
                100L
        );

        assertEquals(1L, q.getId());
        assertEquals("What is Java?", q.getQuestionText());
        assertEquals("Language", q.getOption1());
        assertEquals("Animal", q.getOption2());
        assertEquals("Island", q.getOption3());
        assertEquals("Coffee", q.getOption4());
        assertEquals("Language", q.getCorrectAnswer());
        assertEquals(100L, q.getQuizId());
    }

    @Test
    void testNoArgsConstructorAndSetters() {
        Question q = new Question();
        q.setId(2L);
        q.setQuestionText("What is Python?");
        q.setOption1("Snake");
        q.setOption2("Language");
        q.setOption3("Game");
        q.setOption4("Food");
        q.setCorrectAnswer("Language");
        q.setQuizId(200L);

        assertEquals(2L, q.getId());
        assertEquals("What is Python?", q.getQuestionText());
        assertEquals("Snake", q.getOption1());
        assertEquals("Language", q.getOption2());
        assertEquals("Game", q.getOption3());
        assertEquals("Food", q.getOption4());
        assertEquals("Language", q.getCorrectAnswer());
        assertEquals(200L, q.getQuizId());
    }

    @Test
    void testValidationFailsWhenFieldsBlankOrNull() {
        Question q = new Question();
        q.setId(3L);
        // leave all fields blank/null

        Set<ConstraintViolation<Question>> violations = validator.validate(q);

        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getMessage().contains("must not be blank")));
        assertTrue(violations.stream().anyMatch(v -> v.getMessage().contains("must not be null")));
    }

    @Test
    void testValidationPassesWithValidData() {
        Question q = new Question(
                null,
                "Valid Question?",
                "A",
                "B",
                "C",
                "D",
                "A",
                10L
        );

        Set<ConstraintViolation<Question>> violations = validator.validate(q);

        assertTrue(violations.isEmpty(), "Expected no validation errors for valid Question");
    }

    @Test
    void testEqualsAndHashCode() {
        Question q1 = new Question(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        Question q2 = new Question(1L, "Q1", "A", "B", "C", "D", "A", 100L);

        assertEquals(q1, q2);
        assertEquals(q1.hashCode(), q2.hashCode());
    }

    @Test
    void testToStringContainsFields() {
        Question q = new Question(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        String str = q.toString();

        assertTrue(str.contains("Q1"));
        assertTrue(str.contains("quizId=100"));
    }
}
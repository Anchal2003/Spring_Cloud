package com.quizapp.question_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionServiceApplicationTests {

    @Test
    void contextLoads() {
        // This test will fail if the application context cannot start
    }
}
package com.quizapp.quiz_service.service;

import com.quizapp.quiz_service.dto.AdminQuizWithQuestionsDto;
import com.quizapp.quiz_service.dto.QuestionDto;
import com.quizapp.quiz_service.dto.QuizDto;
import com.quizapp.quiz_service.dto.QuizQuestionDto;
import com.quizapp.quiz_service.dto.QuizWithQuestionsDto;
import com.quizapp.quiz_service.exception.ResourceNotFoundException;
import com.quizapp.quiz_service.feign.QuestionClient;
import com.quizapp.quiz_service.model.Question;
import com.quizapp.quiz_service.model.Quiz;
import com.quizapp.quiz_service.repository.QuizRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuizService {

    private final QuizRepository quizRepo;
    private final QuestionClient questionClient;

    public Quiz createQuiz(QuizDto dto) {
        Quiz quiz = new Quiz();
        quiz.setTitle(dto.getTitle());
        quiz.setDescription(dto.getDescription());
        quiz.setTimeLimit(dto.getTimeLimit());
        return quizRepo.save(quiz);
    }

    public List<Quiz> getAllQuizzes() {
        return quizRepo.findAll();
    }

    public Quiz updateQuiz(Long id, QuizDto dto) {
        Quiz quiz = quizRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Quiz not found"));
        quiz.setTitle(dto.getTitle());
        quiz.setDescription(dto.getDescription());
        quiz.setTimeLimit(dto.getTimeLimit());
        return quizRepo.save(quiz);
    }

    public void deleteQuiz(Long id) {
        quizRepo.deleteById(id);
    }

    public Quiz getQuizById(Long id) {
        return quizRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Quiz not found"));
    }

    public QuizWithQuestionsDto getQuizWithQuestions(Long id) {
        Quiz quiz = getQuizById(id);
        List<Question> questions = questionClient.getQuestionsForUser(id);
        List<QuizQuestionDto> questionDtos = questions.stream()
                .map(q -> new QuizQuestionDto(q.getId(), q.getQuestionText(), q.getOption1(), 
                         q.getOption2(), q.getOption3(), q.getOption4()))
                .toList();
        return new QuizWithQuestionsDto(quiz.getId(), quiz.getTitle(), quiz.getDescription(), quiz.getTimeLimit(), questionDtos);
    }

    public AdminQuizWithQuestionsDto getAdminQuizWithQuestions(Long id) {
        Quiz quiz = getQuizById(id);
        List<QuestionDto> questions = questionClient.getQuestionsByQuiz(id);
        return new AdminQuizWithQuestionsDto(quiz.getId(), quiz.getTitle(), quiz.getDescription(), questions);
    }
}

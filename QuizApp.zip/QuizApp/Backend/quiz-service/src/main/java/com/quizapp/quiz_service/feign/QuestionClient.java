package com.quizapp.quiz_service.feign;

import com.quizapp.quiz_service.dto.QuestionDto;
import com.quizapp.quiz_service.dto.QuizQuestionDto;
import com.quizapp.quiz_service.model.Question;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "question-service")
public interface QuestionClient {

    @GetMapping("/questions/quiz/{quizId}")
    List<QuestionDto> getQuestionsByQuiz(@PathVariable("quizId") Long quizId);

    @GetMapping("/questions/quiz/{quizId}/user")
    List<Question> getQuestionsForUser(@PathVariable("quizId") Long quizId);
}

package com.quizapp.quiz_service.dto;

import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizWithQuestionsDto {
    private Long id;
    private String title;
    private String description;
    private Integer timeLimit;
    private List<QuizQuestionDto> questions;
}
package com.quizapp.quiz_service.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.Map;

@Entity
@Table(name = "quiz_attempts")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizAttempt {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long userId;
    private Long quizId;
    private String quizTitle;
    private Integer score;
    private Integer totalQuestions;
    private Double percentage;
    private LocalDateTime attemptDate;
    
    @ElementCollection
    @CollectionTable(name = "attempt_answers")
    @MapKeyColumn(name = "question_id")
    @Column(name = "answer")
    private Map<Long, String> answers;
    
    @PrePersist
    protected void onCreate() {
        attemptDate = LocalDateTime.now();
        if (totalQuestions != null && totalQuestions > 0) {
            percentage = (score.doubleValue() / totalQuestions) * 100;
        }
    }
}
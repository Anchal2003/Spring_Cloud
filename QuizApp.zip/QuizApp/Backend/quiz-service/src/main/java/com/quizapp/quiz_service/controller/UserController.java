package com.quizapp.quiz_service.controller;

import com.quizapp.quiz_service.dto.QuizAttemptDto;
import com.quizapp.quiz_service.dto.QuizSubmissionDto;
import com.quizapp.quiz_service.dto.QuizWithQuestionsDto;
import com.quizapp.quiz_service.model.Quiz;
import com.quizapp.quiz_service.service.QuizService;
import com.quizapp.quiz_service.service.QuizAttemptService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/quizzes")
@RequiredArgsConstructor
public class UserController {

    private final QuizService quizService;
    private final QuizAttemptService quizAttemptService;

    @GetMapping
    public ResponseEntity<List<Quiz>> viewAvailableQuizzes() {
        return ResponseEntity.ok(quizService.getAllQuizzes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<QuizWithQuestionsDto> viewQuiz(@PathVariable Long id) {
        return ResponseEntity.ok(quizService.getQuizWithQuestions(id));
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<QuizAttemptDto> submitQuiz(@PathVariable Long id, 
                                                   @RequestBody QuizSubmissionDto submission,
                                                   @RequestHeader("X-Username") String username) {
        Long userId = getUserIdFromUsername(username);
        return ResponseEntity.ok(quizAttemptService.submitQuiz(userId, id, submission));
    }

    @GetMapping("/attempts")
    public ResponseEntity<List<QuizAttemptDto>> viewMyAttempts(@RequestHeader("X-Username") String username) {
        Long userId = getUserIdFromUsername(username);
        return ResponseEntity.ok(quizAttemptService.getUserAttempts(userId));
    }

    @GetMapping("/attempts/{attemptId}")
    public ResponseEntity<QuizAttemptDto> viewAttempt(@PathVariable Long attemptId, 
                                                    @RequestHeader("X-Username") String username) {
        Long userId = getUserIdFromUsername(username);
        return ResponseEntity.ok(quizAttemptService.getAttemptById(attemptId, userId));
    }

    private Long getUserIdFromUsername(String username) {
        // Simple mapping - use absolute value to ensure positive ID
        return Math.abs((long) username.hashCode());
    }
}
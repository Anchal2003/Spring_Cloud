package com.quizapp.quiz_service.dto;

import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminQuizWithQuestionsDto {
    private Long id;
    private String title;
    private String description;
    private List<QuestionDto> questions;
}
# Quiz Portal - Backend Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                 CLIENT LAYER                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Angular Frontend (Port: 4200)                                                 │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │   Login/Auth    │  │  Admin Panel    │  │  User Dashboard │                │
│  │   Components    │  │   Components    │  │   Components    │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP/REST API
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              API GATEWAY LAYER                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Spring Cloud Gateway (Port: 8080)                                             │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                        Route Configuration                              │   │
│  │  /auth/**           → Auth Service                                      │   │
│  │  /admin/quizzes/**  → Quiz Service (Admin)                             │   │
│  │  /user/quizzes/**   → Quiz Service (User)                              │   │
│  │  /questions/**      → Question Service                                 │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                     Security Filters                                   │   │
│  │  • JWT Authentication Filter                                           │   │
│  │  • CORS Configuration                                                  │   │
│  │  • Rate Limiting                                                       │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Load Balancing
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           SERVICE DISCOVERY LAYER                              │
├─────────────────────────────────────────────────────────────────────────────────┤
│  Eureka Server (Port: 8761)                                                    │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                    Service Registry                                     │   │
│  │  • auth-service                                                        │   │
│  │  • quiz-service                                                        │   │
│  │  • question-service                                                    │   │
│  │  • api-gateway                                                         │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Service Communication
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            MICROSERVICES LAYER                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐     │
│  │   AUTH SERVICE      │  │   QUIZ SERVICE      │  │ QUESTION SERVICE    │     │
│  │   (Port: 8081)      │  │   (Port: 8082)      │  │   (Port: 8083)      │     │
│  │                     │  │                     │  │                     │     │
│  │ ┌─────────────────┐ │  │ ┌─────────────────┐ │  │ ┌─────────────────┐ │     │
│  │ │  Controllers    │ │  │ │  Controllers    │ │  │ │  Controllers    │ │     │
│  │ │ • AuthController│ │  │ │ • AdminController│ │  │ │• QuestionController│ │     │
│  │ └─────────────────┘ │  │ │ • UserController│ │  │ └─────────────────┘ │     │
│  │                     │  │ └─────────────────┘ │  │                     │     │
│  │ ┌─────────────────┐ │  │                     │  │ ┌─────────────────┐ │     │
│  │ │   Services      │ │  │ ┌─────────────────┐ │  │ │   Services      │ │     │
│  │ │ • UserService   │ │  │ │   Services      │ │  │ │• QuestionService│ │     │
│  │ │ • JwtUtil       │ │  │ │ • QuizService   │ │  │ └─────────────────┘ │     │
│  │ └─────────────────┘ │  │ │ • AttemptService│ │  │                     │     │
│  │                     │  │ └─────────────────┘ │  │ ┌─────────────────┐ │     │
│  │ ┌─────────────────┐ │  │                     │  │ │  Repositories   │ │     │
│  │ │  Repositories   │ │  │ ┌─────────────────┐ │  │ │• QuestionRepo   │ │     │
│  │ │ • UserRepository│ │  │ │  Repositories   │ │  │ └─────────────────┘ │     │
│  │ └─────────────────┘ │  │ │ • QuizRepository│ │  │                     │     │
│  │                     │  │ │ • AttemptRepo   │ │  │ ┌─────────────────┐ │     │
│  │ ┌─────────────────┐ │  │ └─────────────────┘ │  │ │    Entities     │ │     │
│  │ │    Entities     │ │  │                     │  │ │ • Question      │ │     │
│  │ │ • User          │ │  │ ┌─────────────────┐ │  │ └─────────────────┘ │     │
│  │ │ • Role (Enum)   │ │  │ │    Entities     │ │  │                     │     │
│  │ └─────────────────┘ │  │ │ • Quiz          │ │  └─────────────────────┘     │
│  │                     │  │ │ • QuizAttempt   │ │                              │
│  │ ┌─────────────────┐ │  │ └─────────────────┘ │                              │
│  │ │   Security      │ │  │                     │                              │
│  │ │ • JWT Filter    │ │  └─────────────────────┘                              │
│  │ • Auth Manager    │ │                                                       │
│  │ └─────────────────┘ │                                                       │
│  └─────────────────────┘                                                       │
└─────────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ JPA/Hibernate
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              DATABASE LAYER                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│  H2 Database (In-Memory/File-based)                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                          Database Schema                                │   │
│  │                                                                         │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │   │
│  │  │    USERS    │  │    QUIZ     │  │  QUESTIONS  │  │ QUIZ_ATTEMPTS│   │   │
│  │  │─────────────│  │─────────────│  │─────────────│  │─────────────│   │   │
│  │  │ id (PK)     │  │ id (PK)     │  │ id (PK)     │  │ id (PK)     │   │   │
│  │  │ username    │  │ title       │  │ quiz_id(FK) │  │ user_id(FK) │   │   │
│  │  │ password    │  │ description │  │ question_text│  │ quiz_id(FK) │   │   │
│  │  │ email       │  │ duration    │  │ option1     │  │ score       │   │   │
│  │  │ full_name   │  │ total_marks │  │ option2     │  │ total_ques  │   │   │
│  │  │ phone       │  │ passing_marks│  │ option3     │  │ percentage  │   │   │
│  │  │ role        │  │ active      │  │ option4     │  │ attempt_date│   │   │
│  │  │ created_at  │  │ created_at  │  │ correct_ans │  │ answers     │   │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│                              COMMUNICATION FLOW                                │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  1. User Login:                                                                 │
│     Frontend → API Gateway → Auth Service → Database                           │
│     ← JWT Token ← ← ←                                                          │
│                                                                                 │
│  2. Admin Creates Quiz:                                                         │
│     Frontend → API Gateway → Quiz Service → Database                           │
│                                                                                 │
│  3. Admin Adds Questions:                                                       │
│     Frontend → API Gateway → Question Service → Database                       │
│                                                                                 │
│  4. User Takes Quiz:                                                            │
│     Frontend → API Gateway → Quiz Service → Question Service → Database        │
│                                                                                 │
│  5. Submit Quiz:                                                                │
│     Frontend → API Gateway → Quiz Service → Database                           │
│     ← Results ← ← ←                                                            │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────────┐
│                              SECURITY ARCHITECTURE                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  • JWT Token-based Authentication                                              │
│  • Role-based Authorization (ADMIN, USER)                                      │
│  • API Gateway Security Filters                                                │
│  • CORS Configuration                                                           │
│  • Password Encryption (BCrypt)                                                │
│  • Input Validation & Sanitization                                             │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Key Architecture Components:

### **1. API Gateway (Port: 8080)**
- Single entry point for all client requests
- JWT authentication and authorization
- Load balancing and routing
- CORS handling

### **2. Service Discovery (Port: 8761)**
- Eureka server for service registration
- Dynamic service discovery
- Health monitoring

### **3. Microservices**
- **Auth Service (8081)**: User authentication, JWT management
- **Quiz Service (8082)**: Quiz CRUD, attempt management
- **Question Service (8083)**: Question management

### **4. Database Layer**
- H2 in-memory database
- JPA/Hibernate ORM
- Relational data model

### **5. Security**
- JWT token-based authentication
- Role-based access control
- Encrypted passwords
- Secure API endpoints
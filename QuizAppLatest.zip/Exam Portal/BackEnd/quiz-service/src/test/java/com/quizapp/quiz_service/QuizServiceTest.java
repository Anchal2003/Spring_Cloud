
package com.quizapp.quiz_service;

import com.quizapp.quiz_service.dto.QuizDto;
import com.quizapp.quiz_service.exception.ResourceNotFoundException;
import com.quizapp.quiz_service.feign.QuestionClient;
import com.quizapp.quiz_service.model.Quiz;
import com.quizapp.quiz_service.repository.QuizRepository;
import com.quizapp.quiz_service.service.QuizService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QuizServiceTest {

    @Mock
    private QuizRepository quizRepo;

    @Mock
    private QuestionClient questionClient;

    @InjectMocks
    private QuizService quizService;

    private QuizDto quizDto;
    private Quiz existingQuiz;

    @BeforeEach
    void setUp() {
        quizDto = new QuizDto();
        quizDto.setTitle("Java Basics");
        quizDto.setDescription("Core Java topics");
        quizDto.setTimeLimit(30);

        existingQuiz = new Quiz();
        existingQuiz.setId(1L);
        existingQuiz.setTitle("Old Title");
        existingQuiz.setDescription("Old Description");
        existingQuiz.setTimeLimit(20);
    }

    // --- createQuiz ---
    @Test
    void createQuiz_shouldSaveAndReturnQuiz() {
        // Arrange
        Quiz saved = new Quiz();
        saved.setId(42L);
        saved.setTitle(quizDto.getTitle());
        saved.setDescription(quizDto.getDescription());
        saved.setTimeLimit(quizDto.getTimeLimit());

        when(quizRepo.save(any(Quiz.class))).thenReturn(saved);

        // Act
        Quiz result = quizService.createQuiz(quizDto);

        // Assert
        ArgumentCaptor<Quiz> captor = ArgumentCaptor.forClass(Quiz.class);
        verify(quizRepo, times(1)).save(captor.capture());

        Quiz toSave = captor.getValue();
        assertThat(toSave.getId()).isNull(); // new entity should not have id set
        assertThat(toSave.getTitle()).isEqualTo("Java Basics");
        assertThat(toSave.getDescription()).isEqualTo("Core Java topics");
        assertThat(toSave.getTimeLimit()).isEqualTo(30);

        assertThat(result.getId()).isEqualTo(42L);
        assertThat(result.getTitle()).isEqualTo("Java Basics");
        assertThat(result.getDescription()).isEqualTo("Core Java topics");
        assertThat(result.getTimeLimit()).isEqualTo(30);
    }

    // --- getAllQuizzes ---
    @Test
    void getAllQuizzes_shouldReturnList() {
        // Arrange
        Quiz q1 = new Quiz();
        q1.setId(1L);
        q1.setTitle("Quiz 1");
        Quiz q2 = new Quiz();
        q2.setId(2L);
        q2.setTitle("Quiz 2");
        when(quizRepo.findAll()).thenReturn(List.of(q1, q2));

        // Act
        List<Quiz> result = quizService.getAllQuizzes();

        // Assert
        verify(quizRepo, times(1)).findAll();
        assertThat(result).hasSize(2);
        assertThat(result.stream().map(Quiz::getTitle)).containsExactly("Quiz 1", "Quiz 2");
    }

    // --- updateQuiz (happy path) ---
    @Test
    void updateQuiz_shouldUpdateFieldsAndSave_whenQuizExists() {
        // Arrange
        when(quizRepo.findById(1L)).thenReturn(Optional.of(existingQuiz));

        Quiz saved = new Quiz();
        saved.setId(1L);
        saved.setTitle(quizDto.getTitle());
        saved.setDescription(quizDto.getDescription());
        saved.setTimeLimit(quizDto.getTimeLimit());
        when(quizRepo.save(any(Quiz.class))).thenReturn(saved);

        // Act
        Quiz result = quizService.updateQuiz(1L, quizDto);

        // Assert
        verify(quizRepo).findById(1L);
        ArgumentCaptor<Quiz> captor = ArgumentCaptor.forClass(Quiz.class);
        verify(quizRepo).save(captor.capture());

        Quiz updated = captor.getValue();
        assertThat(updated.getId()).isEqualTo(1L);
        assertThat(updated.getTitle()).isEqualTo("Java Basics");
        assertThat(updated.getDescription()).isEqualTo("Core Java topics");
        assertThat(updated.getTimeLimit()).isEqualTo(30);

        assertThat(result.getTitle()).isEqualTo("Java Basics");
        assertThat(result.getDescription()).isEqualTo("Core Java topics");
        assertThat(result.getTimeLimit()).isEqualTo(30);
    }

    // --- updateQuiz (not found) ---
    @Test
    void updateQuiz_shouldThrowResourceNotFound_whenQuizMissing() {
        // Arrange
        when(quizRepo.findById(99L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThatThrownBy(() -> quizService.updateQuiz(99L, quizDto))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessage("Quiz not found");

        verify(quizRepo, never()).save(any());
    }

    // --- deleteQuiz ---
    @Test
    void deleteQuiz_shouldDelegateToRepository() {
        // Act
        quizService.deleteQuiz(5L);

        // Assert
        verify(quizRepo, times(1)).deleteById(5L);
    }

    // --- getQuizById (happy path) ---
    @Test
    void getQuizById_shouldReturnQuiz_whenExists() {
        // Arrange
        when(quizRepo.findById(1L)).thenReturn(Optional.of(existingQuiz));

        // Act
        Quiz result = quizService.getQuizById(1L);

        // Assert
        verify(quizRepo).findById(1L);
        assertThat(result).isSameAs(existingQuiz);
    }

    // --- getQuizById (not found) ---
    @Test
    void getQuizById_shouldThrowResourceNotFound_whenMissing() {
        // Arrange
        when(quizRepo.findById(404L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThatThrownBy(() -> quizService.getQuizById(404L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessage("Quiz not found");
    }


}
package com.quizapp.quiz_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizDto {
    private Long id;
    private String title;
    private String description;
    private Integer timeLimit;
}

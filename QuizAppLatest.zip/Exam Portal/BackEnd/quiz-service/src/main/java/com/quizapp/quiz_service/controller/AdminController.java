package com.quizapp.quiz_service.controller;

import com.quizapp.quiz_service.dto.AdminQuizWithQuestionsDto;
import com.quizapp.quiz_service.dto.QuizDto;
import com.quizapp.quiz_service.model.Quiz;
import com.quizapp.quiz_service.service.QuizService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/quizzes")
@RequiredArgsConstructor
public class AdminController {

    private final QuizService quizService;

    @PostMapping
    public ResponseEntity<Quiz> addQuiz(@RequestBody QuizDto dto, @RequestHeader("X-Username") String username) {
        return ResponseEntity.ok(quizService.createQuiz(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Quiz> updateQuiz(@PathVariable Long id, @RequestBody QuizDto dto, @RequestHeader("X-Username") String username) {
        return ResponseEntity.ok(quizService.updateQuiz(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQuiz(@PathVariable Long id, @RequestHeader("X-Username") String username) {
        quizService.deleteQuiz(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Quiz>> viewAllQuizzes(@RequestHeader("X-Username") String username) {
        return ResponseEntity.ok(quizService.getAllQuizzes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdminQuizWithQuestionsDto> viewQuiz(@PathVariable Long id, @RequestHeader("X-Username") String username) {
        return ResponseEntity.ok(quizService.getAdminQuizWithQuestions(id));
    }
}
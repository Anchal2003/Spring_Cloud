package com.quizapp.quiz_service.service;

import com.quizapp.quiz_service.dto.QuestionDto;
import com.quizapp.quiz_service.dto.QuizAttemptDto;
import com.quizapp.quiz_service.dto.QuizSubmissionDto;
import com.quizapp.quiz_service.exception.ResourceNotFoundException;
import com.quizapp.quiz_service.feign.QuestionClient;
import com.quizapp.quiz_service.model.Quiz;
import com.quizapp.quiz_service.model.QuizAttempt;
import com.quizapp.quiz_service.repository.QuizAttemptRepository;
import com.quizapp.quiz_service.repository.QuizRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.lang.module.ResolutionException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuizAttemptService {

    private final QuizAttemptRepository attemptRepo;
    private final QuizRepository quizRepo;
    private final QuestionClient questionClient;

    public QuizAttemptDto submitQuiz(Long userId, Long quizId, QuizSubmissionDto submission) {
        Quiz quiz = quizRepo.findById(quizId)
                .orElseThrow(() -> new ResourceNotFoundException("Quiz not found"));
        
        // Get questions for this quiz
        List<QuestionDto> questions = questionClient.getQuestionsByQuiz(quizId);
        
        // Calculate score by checking correct answers
        int score = 0;
        int totalQuestions = questions.size();
        
        for (QuestionDto question : questions) {
            String userAnswer = submission.getAnswers().get(question.getId());
            String correctAnswer = question.getCorrectAnswer();
            System.out.println(userAnswer);
            System.out.println(correctAnswer);

            
            if (userAnswer != null && userAnswer.trim().equals(correctAnswer.trim())) {
                score++;
            }
        }
        
        QuizAttempt attempt = new QuizAttempt();
        attempt.setUserId(userId);
        attempt.setQuizId(quizId);
        attempt.setQuizTitle(quiz.getTitle());
        attempt.setScore(score);
        attempt.setTotalQuestions(totalQuestions);
        attempt.setAnswers(submission.getAnswers());
        
        QuizAttempt saved = attemptRepo.save(attempt);
        return convertToDto(saved);
    }

    public List<QuizAttemptDto> getUserAttempts(Long userId) {
        List<QuizAttempt> attempts = attemptRepo.findByUserIdOrderByAttemptDateDesc(userId);
        return attempts.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public QuizAttemptDto getAttemptById(Long attemptId, Long userId) {
        QuizAttempt attempt = attemptRepo.findById(attemptId)
                .orElseThrow(() -> new ResourceNotFoundException("Attempt not found"));
        
        if (!attempt.getUserId().equals(userId)) {
            throw new RuntimeException("Access denied");
        }
        
        return convertToDto(attempt);
    }

    private QuizAttemptDto convertToDto(QuizAttempt attempt) {
        return new QuizAttemptDto(
                attempt.getId(),
                attempt.getUserId(),
                attempt.getQuizId(),
                attempt.getQuizTitle(),
                attempt.getScore(),
                attempt.getTotalQuestions(),
                attempt.getPercentage(),
                attempt.getAttemptDate(),
                attempt.getAnswers()
        );
    }
}
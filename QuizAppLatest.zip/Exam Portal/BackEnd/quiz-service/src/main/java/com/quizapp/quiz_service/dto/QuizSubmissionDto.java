package com.quizapp.quiz_service.dto;

import lombok.*;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizSubmissionDto {
    private Map<Long, String> answers;
}
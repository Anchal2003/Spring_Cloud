package com.quizapp.auth_service.controller;

import com.quizapp.auth_service.dto.AuthRequest;
import com.quizapp.auth_service.dto.AuthResponse;
import com.quizapp.auth_service.dto.RegisterRequest;
import com.quizapp.auth_service.dto.UserProfileDto;
import com.quizapp.auth_service.dto.UpdateRoleRequest;
import com.quizapp.auth_service.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterRequest request) {
       return authService.register(request);
    }

    @GetMapping("/profile")
    public ResponseEntity<UserProfileDto> getProfile(@RequestHeader("X-Username") String username) {
        return  authService.getProfile(username);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
        return authService.login(request);
    }

    // Admin endpoints
    @GetMapping("/admin/users")
    public ResponseEntity<List<UserProfileDto>> getAllUsers(@RequestHeader("X-Username") String username) {
        return authService.getAllUsers(username);
    }

    @PutMapping("/admin/users/{userId}/role")
    public ResponseEntity<UserProfileDto> updateUserRole(
            @PathVariable Long userId,
            @RequestBody UpdateRoleRequest request,
            @RequestHeader("X-Username") String username) {
        return authService.updateUserRole(userId, request, username);
    }

    @DeleteMapping("/admin/users/{userId}")
    public ResponseEntity<Void> deleteUser(
            @PathVariable Long userId,
            @RequestHeader("X-Username") String username) {
        return authService.deleteUser(userId, username);
    }
}


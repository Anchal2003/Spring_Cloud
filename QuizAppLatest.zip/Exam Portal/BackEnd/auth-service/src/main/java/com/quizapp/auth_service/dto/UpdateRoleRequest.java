package com.quizapp.auth_service.dto;

import lombok.Data;

@Data
public class UpdateRoleRequest {
    private String role;
}
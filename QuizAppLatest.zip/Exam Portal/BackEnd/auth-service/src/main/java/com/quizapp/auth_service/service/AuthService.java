package com.quizapp.auth_service.service;

import com.quizapp.auth_service.dto.AuthRequest;
import com.quizapp.auth_service.dto.AuthResponse;
import com.quizapp.auth_service.dto.RegisterRequest;
import com.quizapp.auth_service.dto.UserProfileDto;
import com.quizapp.auth_service.dto.UpdateRoleRequest;
import com.quizapp.auth_service.exception.ResourceNotFoundException;
import com.quizapp.auth_service.model.Role;
import com.quizapp.auth_service.model.User;
import com.quizapp.auth_service.repository.UserRepository;
import com.quizapp.auth_service.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;


    public ResponseEntity<String> register(RegisterRequest request) {
        if (userRepo.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username already exists");
        }
        if (userRepo.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Email already exists");
        }
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEmail(request.getEmail());
        user.setFullName(request.getFullName());
        user.setPhone(request.getPhone());
        user.setRole(Role.USER);
        userRepo.save(user);
        return ResponseEntity.ok("User registered successfully");
    }


    public ResponseEntity<UserProfileDto> getProfile(String username) {
        try {
            User user = userRepo.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
            UserProfileDto profile = new UserProfileDto();
            profile.setId(user.getId());
            profile.setUsername(user.getUsername());
            profile.setEmail(user.getEmail());
            profile.setFullName(user.getFullName());
            profile.setPhone(user.getPhone());
            profile.setRole(user.getRole().toString());
            profile.setCreatedAt(user.getCreatedAt() != null ? user.getCreatedAt().toString() : "");
            return ResponseEntity.ok(profile);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    public ResponseEntity<AuthResponse> login(AuthRequest request) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        User user = userRepo.findByUsername(request.getUsername()).get();
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
        return ResponseEntity.ok(new AuthResponse(token));
    }

    // Admin methods
    public ResponseEntity<List<UserProfileDto>> getAllUsers(String adminUsername) {
        try {
            User admin = userRepo.findByUsername(adminUsername).orElseThrow(() -> new ResourceNotFoundException("Admin not found"));
            if (admin.getRole() != Role.ADMIN) {
                return ResponseEntity.status(403).build();
            }
            
            List<User> users = userRepo.findAll();
            List<UserProfileDto> userProfiles = users.stream()
                    .map(this::convertToUserProfileDto)
                    .collect(Collectors.toList());
            
            return ResponseEntity.ok(userProfiles);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

    public ResponseEntity<UserProfileDto> updateUserRole(Long userId, UpdateRoleRequest request, String adminUsername) {
        try {
            User admin = userRepo.findByUsername(adminUsername).orElseThrow(() -> new RuntimeException("Admin not found"));
            if (admin.getRole() != Role.ADMIN) {
                return ResponseEntity.status(403).build();
            }
            
            User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
            Role newRole = Role.valueOf(request.getRole().toUpperCase());
            user.setRole(newRole);
            userRepo.save(user);
            
            return ResponseEntity.ok(convertToUserProfileDto(user));
        } catch (Exception e) {
            return ResponseEntity.status(400).build();
        }
    }

    public ResponseEntity<Void> deleteUser(Long userId, String adminUsername) {
        try {
            User admin = userRepo.findByUsername(adminUsername).orElseThrow(() -> new RuntimeException("Admin not found"));
            if (admin.getRole() != Role.ADMIN) {
                return ResponseEntity.status(403).build();
            }
            
            User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
            
            // Prevent admin from deleting themselves
            if (user.getId().equals(admin.getId())) {
                return ResponseEntity.status(400).build();
            }
            
            userRepo.deleteById(userId);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(400).build();
        }
    }

    private UserProfileDto convertToUserProfileDto(User user) {
        UserProfileDto profile = new UserProfileDto();
        profile.setId(user.getId());
        profile.setUsername(user.getUsername());
        profile.setEmail(user.getEmail());
        profile.setFullName(user.getFullName());
        profile.setPhone(user.getPhone());
        profile.setRole(user.getRole().toString());
        profile.setCreatedAt(user.getCreatedAt() != null ? user.getCreatedAt().toString() : "");
        return profile;
    }
}

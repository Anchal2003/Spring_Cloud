package com.quizapp.question_service;

import com.quizapp.question_service.exception.GlobalExceptionHandler;
import com.quizapp.question_service.exception.ResourceNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void testHandleResourceNotFoundException() {
        ResourceNotFoundException ex = new ResourceNotFoundException("Resource not found!");
        ResponseEntity<String> response = handler.handleResourceNotFoundException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Resource not found!", response.getBody());
    }

    @Test
    void testHandleIllegalAccessException() {
        IllegalAccessException ex = new IllegalAccessException("Illegal access!");
        ResponseEntity<String> response = handler.handleIllegalAccessException(ex);

        assertEquals(HttpStatus.NOT_ACCEPTABLE, response.getStatusCode());
        assertEquals("Illegal access!", response.getBody());
    }

    @Test
    void testHandleValidationException() {
        // Simulate a validation error
        BeanPropertyBindingResult bindingResult = new BeanPropertyBindingResult(new Object(), "objectName");
        bindingResult.addError(new FieldError("objectName", "field1", "must not be blank"));
        bindingResult.addError(new FieldError("objectName", "field2", "must not be null"));

        MethodArgumentNotValidException ex =
                new MethodArgumentNotValidException(null, bindingResult);

        ResponseEntity<String> response = handler.handleValidationException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        String body = response.getBody();
        assertNotNull(body);
        assertTrue(body.contains("field1: must not be blank"));
        assertTrue(body.contains("field2: must not be null"));
    }
}
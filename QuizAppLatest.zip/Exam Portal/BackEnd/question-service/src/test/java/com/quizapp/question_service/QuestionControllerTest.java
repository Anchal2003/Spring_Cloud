package com.quizapp.question_service;

import com.quizapp.question_service.controller.QuestionController;
import com.quizapp.question_service.dto.QuestionDto;
import com.quizapp.question_service.model.Question;
import com.quizapp.question_service.service.QuestionService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(QuestionController.class)
class QuestionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private QuestionService questionService;

    @Test
    void testCreateQuestion() throws Exception {
        Question question = new Question();
        question.setId(1L);
        question.setQuestionText("What is Java?");
        question.setOption1("Language");
        question.setOption2("Animal");
        question.setCorrectAnswer("Language");
        question.setQuizId(100L);

        Mockito.when(questionService.createQuestion(any(QuestionDto.class)))
                .thenReturn(question);

        mockMvc.perform(post("/questions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"questionText\":\"What is Java?\",\"option1\":\"Language\",\"option2\":\"Animal\",\"correctAnswer\":\"Language\",\"quizId\":100}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.questionText", is("What is Java?")))
                .andExpect(jsonPath("$.option1", is("Language")))
                .andExpect(jsonPath("$.correctAnswer", is("Language")));
    }

    @Test
    void testGetByQuiz() throws Exception {
        Question q1 = new Question(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        Question q2 = new Question(2L, "Q2", "X", "Y", "Z", "W", "Y", 100L);
        List<Question> questions = Arrays.asList(q1, q2);

        Mockito.when(questionService.getQuestionsByQuizId(100L)).thenReturn(questions);

        mockMvc.perform(get("/questions/quiz/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].questionText", is("Q1")))
                .andExpect(jsonPath("$[0].correctAnswer", is("optionA")))
                .andExpect(jsonPath("$[1].correctAnswer", is("optionB")));
    }

    @Test
    void testGetByQuizForUser() throws Exception {
        Question q1 = new Question(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        Mockito.when(questionService.getQuestionsForUser(100L)).thenReturn(List.of(q1));

        mockMvc.perform(get("/questions/quiz/100/user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].questionText", is("Q1")));
    }

    @Test
    void testUpdateQuestion() throws Exception {
        Question updated = new Question(1L, "Updated Q", "A", "B", "C", "D", "C", 100L);
        Mockito.when(questionService.updateQuestion(eq(1L), any(QuestionDto.class)))
                .thenReturn(updated);

        mockMvc.perform(put("/questions/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"questionText\":\"Updated Q\",\"option1\":\"A\",\"option2\":\"B\",\"option3\":\"C\",\"option4\":\"D\",\"correctAnswer\":\"C\",\"quizId\":100}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.questionText", is("Updated Q")))
                .andExpect(jsonPath("$.correctAnswer", is("C")));
    }

    @Test
    void testDeleteQuestion() throws Exception {
        mockMvc.perform(delete("/questions/1"))
                .andExpect(status().isNoContent());

        Mockito.verify(questionService).deleteQuestion(1L);
    }
}
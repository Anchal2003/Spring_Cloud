package com.quizapp.question_service;

import com.quizapp.question_service.dto.QuestionDto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuestionDtoTest {

    @Test
    void testAllArgsConstructorAndGetters() {
        QuestionDto dto = new QuestionDto(
                1L,
                "What is Java?",
                "Language",
                "Animal",
                "Island",
                "Coffee",
                "Language",
                100L
        );

        assertEquals(1L, dto.getId());
        assertEquals("What is Java?", dto.getQuestionText());
        assertEquals("Language", dto.getOption1());
        assertEquals("Animal", dto.getOption2());
        assertEquals("Island", dto.getOption3());
        assertEquals("Coffee", dto.getOption4());
        assertEquals("Language", dto.getCorrectAnswer());
        assertEquals(100L, dto.getQuizId());
    }

    @Test
    void testNoArgsConstructorAndSetters() {
        QuestionDto dto = new QuestionDto();
        dto.setId(2L);
        dto.setQuestionText("What is Python?");
        dto.setOption1("Snake");
        dto.setOption2("Language");
        dto.setOption3("Game");
        dto.setOption4("Food");
        dto.setCorrectAnswer("Language");
        dto.setQuizId(200L);

        assertEquals(2L, dto.getId());
        assertEquals("What is Python?", dto.getQuestionText());
        assertEquals("Snake", dto.getOption1());
        assertEquals("Language", dto.getOption2());
        assertEquals("Game", dto.getOption3());
        assertEquals("Food", dto.getOption4());
        assertEquals("Language", dto.getCorrectAnswer());
        assertEquals(200L, dto.getQuizId());
    }

    @Test
    void testEqualsAndHashCode() {
        QuestionDto dto1 = new QuestionDto(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        QuestionDto dto2 = new QuestionDto(1L, "Q1", "A", "B", "C", "D", "A", 100L);

        assertEquals(dto1, dto2);
        assertEquals(dto1.hashCode(), dto2.hashCode());
    }

    @Test
    void testToStringContainsFields() {
        QuestionDto dto = new QuestionDto(1L, "Q1", "A", "B", "C", "D", "A", 100L);
        String str = dto.toString();

        assertTrue(str.contains("Q1"));
        assertTrue(str.contains("A"));
        assertTrue(str.contains("quizId=100"));
    }
}
package com.quizapp.question_service.controller;

import com.quizapp.question_service.dto.QuestionDto;
import com.quizapp.question_service.model.Question;
import com.quizapp.question_service.service.QuestionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/questions")
@RequiredArgsConstructor
public class QuestionController {


    private final QuestionService questionService;


    @PostMapping
    public ResponseEntity<Question> create(@RequestBody QuestionDto dto) {
        return ResponseEntity.ok(questionService.createQuestion(dto));
    }

    @GetMapping("/quiz/{quizId}")
    public ResponseEntity<List<QuestionDto>> getByQuiz(@PathVariable Long quizId) {
        List<Question> questions = questionService.getQuestionsByQuizId(quizId);
        List<QuestionDto> questionDtos = questions.stream()
                .map(this::convertToDto)
                .toList();
        return ResponseEntity.ok(questionDtos);
    }
    
    private QuestionDto convertToDto(Question question) {
        // Convert correct answer text to option label
        String correctOptionLabel = getCorrectOptionLabel(question);
        
        return new QuestionDto(
                question.getId(),
                question.getQuestionText(),
                question.getOption1(),
                question.getOption2(),
                question.getOption3(),
                question.getOption4(),
                correctOptionLabel,
                question.getQuizId()
        );
    }
    
    private String getCorrectOptionLabel(Question question) {
        String correctAnswer = question.getCorrectAnswer();
        if (correctAnswer.equals(question.getOption1())) return "optionA";
        if (correctAnswer.equals(question.getOption2())) return "optionB";
        if (correctAnswer.equals(question.getOption3())) return "optionC";
        if (correctAnswer.equals(question.getOption4())) return "optionD";
        return correctAnswer; // fallback
    }

    @GetMapping("/quiz/{quizId}/user")
    public ResponseEntity<List<Question>> getByQuizForUser(@PathVariable Long quizId) {
        return ResponseEntity.ok(questionService.getQuestionsForUser(quizId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Question> update(@PathVariable Long id, @RequestBody QuestionDto dto) {
        return ResponseEntity.ok(questionService.updateQuestion(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        questionService.deleteQuestion(id);
        return ResponseEntity.noContent().build();
    }
}

export interface Quiz {
  id: number;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  active: boolean;
  createdAt?: string;
}

export interface Question {
  id: number;
  quizId: number;
  questionText: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctAnswer?: string;
}

export interface QuizWithQuestions {
  id: number;
  title: string;
  description: string;
  timeLimit: number;
  questions: QuizQuestionDto[];
}

export interface QuizQuestionDto {
  id: number;
  questionText: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
}

export interface QuizSubmission {
  answers: { [questionId: string]: string };
}

export interface QuizAttempt {
  id: number;
  userId: number;
  quizId: number;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  attemptDate: string;
  answers: { [questionId: string]: string };
}

export interface QuizDto {
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  active: boolean;
}

export interface QuestionDto {
  quizId: number;
  questionText: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctAnswer: string;
}

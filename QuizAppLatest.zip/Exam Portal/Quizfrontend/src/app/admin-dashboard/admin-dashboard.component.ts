import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService, UserProfile } from '../services/auth.service';
import { QuizService, Quiz } from '../services/quiz.service';
import { QuestionService, QuestionDto } from '../services/question.service';

@Component({
  selector: 'app-admin-dashboard',
  imports: [RouterLink, CommonModule, FormsModule],
  template: `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-logo">
          <a routerLink="/home">
            <span class="logo-icon">🎯</span>
            <span class="logo-text">QuizApp Admin</span>
          </a>
        </div>
        <div class="nav-actions">
          <button (click)="viewProfile()" class="profile-btn">
            <span class="btn-icon">👤</span>
            Profile
          </button>
          <button (click)="logout()" class="logout-btn">
            <span class="btn-icon">🚪</span>
            Logout
          </button>
        </div>
      </div>
    </nav>
    
    <div class="hero-banner">
      <div class="hero-content">
        <div class="hero-icon">⚡</div>
        <h1 class="hero-title">Admin Dashboard</h1>
        <p class="hero-subtitle">Manage quizzes and questions with ease</p>
      </div>
      <div class="stats-cards">
        <div class="stat-card">
          <div class="stat-icon">📊</div>
          <div class="stat-number">{{ quizzes.length }}</div>
          <div class="stat-label">Total Quizzes</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">❓</div>
          <div class="stat-number">{{ getTotalQuestions() }}</div>
          <div class="stat-label">Total Questions</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">👥</div>
          <div class="stat-number">{{ users.length }}</div>
          <div class="stat-label">Total Users</div>
        </div>
      </div>
    </div>
    
    <main class="dashboard-content">
      <div class="admin-tabs">
        <button (click)="setActiveTab('quizzes')" [class.active]="activeTab === 'quizzes'" class="tab-btn">
          <span class="tab-icon">📝</span>
          <span>Manage Quizzes</span>
        </button>
        <button (click)="setActiveTab('users')" [class.active]="activeTab === 'users'" class="tab-btn">
          <span class="tab-icon">👥</span>
          <span>Manage Users</span>
        </button>
      </div>

      <!-- User Management -->
      <div *ngIf="activeTab === 'users'" class="tab-content fade-in">
        <div class="section users-section">
          <div class="section-header">
            <h2><span class="section-icon">👥</span>User Management</h2>
            <p class="section-subtitle">Manage user roles and permissions</p>
          </div>
          
          <div class="users-grid" *ngIf="users.length > 0">
            <div *ngFor="let user of users; let i = index" class="user-card" [style.animation-delay.ms]="i * 100">
              <div class="user-card-header">
                <div class="user-avatar">{{ user.fullName.charAt(0).toUpperCase() }}</div>
                <div class="user-role" [class.admin]="user.role === 'ADMIN'" [class.user]="user.role === 'USER'">
                  {{ user.role }}
                </div>
              </div>
              <h3 class="user-name">{{ user.fullName }}</h3>
              <p class="user-username">{{ user.username }}</p>
              <p class="user-email">{{ user.email }}</p>
              <p class="user-phone">{{ user.phone }}</p>
              <p class="user-joined">Joined: {{ formatDate(user.createdAt) }}</p>
              
              <div class="user-actions">
                <select [(ngModel)]="user.selectedRole" class="role-select">
                  <option value="USER">USER</option>
                  <option value="ADMIN">ADMIN</option>
                </select>
                <button 
                  (click)="updateUserRole(user)" 
                  [disabled]="user.selectedRole === user.role || isUpdating"
                  class="update-btn">
                  <span class="btn-icon">🔄</span>
                  Update Role
                </button>
                <button 
                  (click)="deleteUser(user)" 
                  [disabled]="isUpdating"
                  class="delete-user-btn">
                  <span class="btn-icon">🗑️</span>
                  Delete
                </button>
              </div>
            </div>
          </div>
          
          <div *ngIf="users.length === 0" class="empty-state">
            <div class="empty-icon">👥</div>
            <h3>No users found</h3>
            <p>No users are registered in the system yet.</p>
          </div>
        </div>
      </div>

      <!-- Quiz Management -->
      <div *ngIf="activeTab === 'quizzes'" class="tab-content fade-in">
        <div class="section create-section">
          <div class="section-header">
            <h2><span class="section-icon">✨</span>{{ isEditing ? 'Edit Quiz' : 'Create New Quiz' }}</h2>
            <p class="section-subtitle">{{ isEditing ? 'Update your quiz details' : 'Build engaging quizzes for your audience' }}</p>
          </div>
          <form (ngSubmit)="createQuiz()" class="quiz-form modern-form">
            <div class="form-group">
              <label>📝 Quiz Title</label>
              <input [(ngModel)]="newQuiz.title" name="title" placeholder="Enter an engaging title..." required>
            </div>
            <div class="form-group">
              <label>📄 Description</label>
              <textarea [(ngModel)]="newQuiz.description" name="description" placeholder="Describe what this quiz covers..." required></textarea>
            </div>
            <div class="form-group">
              <label>⏱️ Time Limit (minutes)</label>
              <input [(ngModel)]="newQuiz.timeLimit" name="timeLimit" type="number" placeholder="30" required>
            </div>
            <button type="submit" [disabled]="isLoading" class="create-btn">
              <span *ngIf="!isLoading" class="btn-content">
                <span class="btn-icon">{{ isEditing ? '💾' : '🚀' }}</span>
                {{ isEditing ? 'Update Quiz' : 'Create Quiz' }}
              </span>
              <span *ngIf="isLoading" class="loading-spinner">{{ isEditing ? '⏳ Updating...' : '⏳ Creating...' }}</span>
            </button>
            <button *ngIf="isEditing" type="button" (click)="resetForm()" class="cancel-btn">
              <span class="btn-icon">❌</span>
              Cancel
            </button>
          </form>
        </div>

        <div class="section quizzes-section">
          <div class="section-header">
            <h2><span class="section-icon">📚</span>Your Quizzes</h2>
            <p class="section-subtitle">Manage and organize your quiz collection</p>
          </div>
          <div class="quiz-grid" *ngIf="quizzes.length > 0">
            <div *ngFor="let quiz of quizzes; let i = index" class="quiz-card" [style.animation-delay.ms]="i * 100">
              <div class="quiz-card-header">
                <div class="quiz-icon">🎯</div>
                <div class="quiz-status" [class.active]="getQuestionCount(quiz.id) > 0">
                  {{ getQuestionCount(quiz.id) > 0 ? 'Active' : 'Draft' }}
                </div>
              </div>
              <h3 class="quiz-title">{{ quiz.title }}</h3>
              <p class="quiz-description">{{ quiz.description }}</p>
              <div class="quiz-stats">
                <div class="stat">
                  <span class="stat-icon">⏱️</span>
                  <span>{{ quiz.timeLimit }}min</span>
                </div>
                <div class="stat">
                  <span class="stat-icon">❓</span>
                  <span>{{ getQuestionCount(quiz.id) }} questions</span>
                </div>
              </div>
              <div class="quiz-actions">
                <button (click)="viewQuizQuestions(quiz)" class="action-btn view-btn">
                  <span class="btn-icon">👁️</span>
                  View
                </button>
                <button (click)="editQuiz(quiz)" class="action-btn edit-btn">
                  <span class="btn-icon">✏️</span>
                  Edit
                </button>
                <button (click)="selectQuizForQuestions(quiz)" class="action-btn add-btn">
                  <span class="btn-icon">➕</span>
                  Add Q
                </button>
                <button (click)="deleteQuiz(quiz.id)" class="action-btn delete-btn">
                  <span class="btn-icon">🗑️</span>
                  Delete
                </button>
              </div>
            </div>
          </div>
          <div *ngIf="quizzes.length === 0" class="empty-state">
            <div class="empty-icon">📝</div>
            <h3>No quizzes yet</h3>
            <p>Create your first quiz to get started!</p>
          </div>
        </div>
      </div>

      <!-- Question Management -->
      <div *ngIf="activeTab === 'questions'" class="tab-content fade-in">
        <div class="section create-section" *ngIf="selectedQuiz">
          <div class="section-header">
            <h2><span class="section-icon">❓</span>Add Question</h2>
            <p class="section-subtitle">Adding to: <strong>{{ selectedQuiz.title }}</strong></p>
          </div>
          <form (ngSubmit)="createQuestion()" class="question-form modern-form">
            <div class="form-group">
              <label>❓ Question Text</label>
              <textarea [(ngModel)]="newQuestion.questionText" name="questionText" placeholder="What would you like to ask?" required></textarea>
            </div>
            <div class="options-grid">
              <div class="form-group">
                <label>🅰️ Option 1</label>
                <input [(ngModel)]="newQuestion.option1" name="option1" placeholder="First option..." required>
              </div>
              <div class="form-group">
                <label>🅱️ Option 2</label>
                <input [(ngModel)]="newQuestion.option2" name="option2" placeholder="Second option..." required>
              </div>
              <div class="form-group">
                <label>🅲 Option 3</label>
                <input [(ngModel)]="newQuestion.option3" name="option3" placeholder="Third option..." required>
              </div>
              <div class="form-group">
                <label>🅳 Option 4</label>
                <input [(ngModel)]="newQuestion.option4" name="option4" placeholder="Fourth option..." required>
              </div>
            </div>
            <div class="form-group">
              <label>✅ Correct Answer</label>
              <select [(ngModel)]="newQuestion.correctAnswer" name="correctAnswer" required>
                <option value="">Select the correct answer...</option>
                <option value="option1">🅰️ Option 1</option>
                <option value="option2">🅱️ Option 2</option>
                <option value="option3">🅲 Option 3</option>
                <option value="option4">🅳 Option 4</option>
              </select>
            </div>
            <button type="submit" [disabled]="isLoading" class="create-btn">
              <span *ngIf="!isLoading" class="btn-content">
                <span class="btn-icon">➕</span>
                Add Question
              </span>
              <span *ngIf="isLoading" class="loading-spinner">⏳ Adding...</span>
            </button>
          </form>
        </div>
        
        <div *ngIf="!selectedQuiz" class="section empty-state">
          <div class="empty-icon">🎯</div>
          <h3>Select a Quiz First</h3>
          <p>Choose a quiz from the Quizzes tab to start adding questions.</p>
          <button (click)="setActiveTab('quizzes')" class="action-btn">
            <span class="btn-icon">📝</span>
            Go to Quizzes
          </button>
        </div>
        
        <div *ngIf="viewingQuestions" class="section questions-section">
          <div class="section-header">
            <h2><span class="section-icon">📋</span>Questions</h2>
            <p class="section-subtitle">Managing: <strong>{{ selectedQuiz?.title }}</strong></p>
            <p>Debug: Found {{ quizQuestions.length || 0 }} questions</p>
          </div>
          
          <div class="questions-grid">
            <div *ngFor="let question of quizQuestions; let i = index" class="question-card" [style.animation-delay.ms]="i * 100">
              <div class="question-card-header">
                <div class="question-number">Q{{ i + 1 }}</div>
                <div class="question-actions">
                  <button (click)="editQuestion(question)" class="action-btn edit-btn">
                    <span class="btn-icon">✏️</span>
                  </button>
                  <button (click)="deleteQuestion(question.id)" class="action-btn delete-btn">
                    <span class="btn-icon">🗑️</span>
                  </button>
                </div>
              </div>
              <p class="question-text">{{ question.questionText }}</p>
              <div class="options-display">
                <div class="option" [class.correct]="question.correctAnswer === 'option1'">
                  <span class="option-label">A</span>
                  <span class="option-text">{{ question.option1 }}</span>
                </div>
                <div class="option" [class.correct]="question.correctAnswer === 'option2'">
                  <span class="option-label">B</span>
                  <span class="option-text">{{ question.option2 }}</span>
                </div>
                <div class="option" [class.correct]="question.correctAnswer === 'option3'">
                  <span class="option-label">C</span>
                  <span class="option-text">{{ question.option3 }}</span>
                </div>
                <div class="option" [class.correct]="question.correctAnswer === 'option4'">
                  <span class="option-label">D</span>
                  <span class="option-text">{{ question.option4 }}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div *ngIf="!quizQuestions || quizQuestions.length === 0" class="empty-state">
            <div class="empty-icon">❓</div>
            <h3>No questions found</h3>
            <p>This quiz doesn't have any questions yet. Add some questions to get started!</p>
          </div>
        </div>
      </div>

      <div *ngIf="message" class="notification" [class.error]="isError" [class.show]="message">
        <div class="notification-icon">{{ isError ? '❌' : '✅' }}</div>
        <span>{{ message }}</span>
      </div>
    </main>
  `,
  
  styles: [`
    .users-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 2rem;
    }
    
    .user-card {
      background: white;
      border-radius: 20px;
      padding: 1.5rem;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      border: 2px solid transparent;
      animation: slideIn 0.6s ease-out;
    }
    
    .user-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0,0,0,0.15);
      border-color: #667eea;
    }
    
    .user-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    
    .user-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      font-weight: bold;
    }
    
    .user-role {
      padding: 0.25rem 0.75rem;
      border-radius: 15px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .user-role.admin {
      background: linear-gradient(45deg, #e74c3c, #c0392b);
      color: white;
    }
    
    .user-role.user {
      background: linear-gradient(45deg, #4ecdc4, #44a08d);
      color: white;
    }
    
    .user-name {
      font-size: 1.3rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 0.25rem;
    }
    
    .user-username {
      color: #667eea;
      font-weight: 600;
      margin-bottom: 0.25rem;
    }
    
    .user-email, .user-phone, .user-joined {
      color: #7f8c8d;
      font-size: 0.9rem;
      margin-bottom: 0.25rem;
    }
    
    .user-actions {
      display: flex;
      gap: 0.5rem;
      align-items: center;
      margin-top: 1rem;
      flex-wrap: wrap;
    }
    
    .role-select {
      padding: 0.5rem;
      border: 2px solid #e9ecef;
      border-radius: 8px;
      font-weight: 600;
      background: white;
      cursor: pointer;
    }
    
    .role-select:focus {
      outline: none;
      border-color: #667eea;
    }
    
    .update-btn {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.3s ease;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
    }
    
    .update-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
    }
    
    .update-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    .delete-user-btn {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.3s ease;
      background: linear-gradient(45deg, #dc3545, #c82333);
      color: white;
    }
    
    .delete-user-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(220, 53, 69, 0.3);
    }
    
    .delete-user-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes slideIn {
      from { opacity: 0; transform: translateX(-30px); }
      to { opacity: 1; transform: translateX(0); }
    }
    
    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }
    
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-10px); }
      60% { transform: translateY(-5px); }
    }
    
    .fade-in {
      animation: fadeIn 0.6s ease-out;
    }
    
    /* Navbar */
    .navbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 1rem 0;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    
    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2rem;
    }
    
    .nav-logo a {
      color: #fff;
      font-size: 1.5rem;
      font-weight: bold;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.3s ease;
    }
    
    .nav-logo a:hover {
      transform: scale(1.05);
    }
    
    .logo-icon {
      font-size: 1.8rem;
      animation: bounce 2s infinite;
    }
    
    .nav-actions {
      display: flex;
      gap: 1rem;
    }
    
    .profile-btn, .logout-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.7rem 1.2rem;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      backdrop-filter: blur(10px);
    }
    
    .profile-btn {
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    .profile-btn:hover {
      background: rgba(255, 255, 255, 0.3);
      transform: translateY(-2px);
    }
    
    .logout-btn {
      background: linear-gradient(45deg, #ff6b6b, #ee5a24);
      color: white;
    }
    
    .logout-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
    }
    
    /* Hero Banner */
    .hero-banner {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      padding: 3rem 2rem;
      color: white;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    
    .hero-content {
      max-width: 800px;
      margin: 0 auto 2rem;
    }
    
    .hero-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      animation: pulse 2s infinite;
    }
    
    .hero-title {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
      background: linear-gradient(45deg, #ffd700, #ffed4e);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .hero-subtitle {
      font-size: 1.2rem;
      opacity: 0.9;
    }
    
    .stats-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      max-width: 800px;
      margin: 0 auto;
    }
    
    .stat-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      padding: 1.5rem;
      text-align: center;
      transition: all 0.3s ease;
      animation: slideIn 0.6s ease-out;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
      background: rgba(255, 255, 255, 0.25);
    }
    
    .stat-icon {
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }
    
    .stat-number {
      font-size: 2.5rem;
      font-weight: bold;
      margin-bottom: 0.25rem;
    }
    
    .stat-label {
      opacity: 0.9;
      font-size: 0.9rem;
    }
    
    /* Dashboard Content */
    .dashboard-content {
      padding: 2rem;
      max-width: 1200px;
      margin: 0 auto;
      min-height: 60vh;
    }
    
    /* Tabs */
    .admin-tabs {
      display: flex;
      gap: 1rem;
      margin-bottom: 2rem;
      justify-content: center;
    }
    
    .tab-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 1rem 2rem;
      border: none;
      background: white;
      cursor: pointer;
      border-radius: 15px;
      font-weight: 600;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .tab-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    .tab-btn.active {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      transform: translateY(-2px);
    }
    
    .tab-icon {
      font-size: 1.2rem;
    }
    
    /* Sections */
    .section {
      background: white;
      padding: 2.5rem;
      margin-bottom: 2rem;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      animation: fadeIn 0.6s ease-out;
    }
    
    .section:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 40px rgba(0,0,0,0.15);
    }
    
    .section-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    
    .section-header h2 {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      font-size: 2rem;
      color: #2c3e50;
      margin-bottom: 0.5rem;
    }
    
    .section-icon {
      font-size: 1.5rem;
    }
    
    .section-subtitle {
      color: #7f8c8d;
      font-size: 1.1rem;
    }
    
    /* Forms */
    .modern-form {
      max-width: 600px;
      margin: 0 auto;
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 600;
      color: #2c3e50;
      font-size: 1rem;
    }
    
    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 1rem;
      border: 2px solid #e9ecef;
      border-radius: 12px;
      font-size: 1rem;
      transition: all 0.3s ease;
      background: #f8f9fa;
    }
    
    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: #667eea;
      background: white;
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .options-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
    }
    
    .create-btn {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 25px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      margin: 1rem auto 0;
    }
    
    .create-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
    }
    
    .create-btn:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }
    
    .cancel-btn {
      background: linear-gradient(45deg, #6c757d, #495057);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 25px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      margin: 0.5rem auto 0;
    }
    
    .cancel-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(108, 117, 125, 0.3);
    }
    
    .loading-spinner {
      animation: pulse 1s infinite;
    }
    
    /* Quiz Grid */
    .quiz-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 2rem;
    }
    
    .quiz-card {
      background: white;
      border-radius: 20px;
      padding: 1.5rem;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      border: 2px solid transparent;
      animation: slideIn 0.6s ease-out;
    }
    
    .quiz-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0,0,0,0.15);
      border-color: #667eea;
    }
    
    .quiz-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    
    .quiz-icon {
      font-size: 2rem;
      animation: bounce 2s infinite;
    }
    
    .quiz-status {
      padding: 0.25rem 0.75rem;
      border-radius: 15px;
      font-size: 0.8rem;
      font-weight: 600;
      background: #f8f9fa;
      color: #6c757d;
    }
    
    .quiz-status.active {
      background: linear-gradient(45deg, #4ecdc4, #44a08d);
      color: white;
    }
    
    .quiz-title {
      font-size: 1.3rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 0.5rem;
    }
    
    .quiz-description {
      color: #7f8c8d;
      margin-bottom: 1rem;
      line-height: 1.5;
    }
    
    .quiz-stats {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
    }
    
    .stat {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      font-size: 0.9rem;
      color: #6c757d;
    }
    
    .quiz-actions {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    
    .action-btn {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.5rem 0.75rem;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    
    .view-btn {
      background: linear-gradient(45deg, #3498db, #2980b9);
      color: white;
    }
    
    .edit-btn {
      background: linear-gradient(45deg, #f39c12, #e67e22);
      color: white;
    }
    
    .add-btn {
      background: linear-gradient(45deg, #27ae60, #229954);
      color: white;
    }
    
    .delete-btn {
      background: linear-gradient(45deg, #e74c3c, #c0392b);
      color: white;
    }
    
    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    /* Questions */
    .questions-grid {
      display: grid;
      gap: 1.5rem;
    }
    
    .question-card {
      background: white;
      border-radius: 15px;
      padding: 1.5rem;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      border: 2px solid #f8f9fa;
      transition: all 0.3s ease;
      animation: slideIn 0.6s ease-out;
    }
    
    .question-card:hover {
      border-color: #667eea;
      transform: translateY(-2px);
    }
    
    .question-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    
    .question-number {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-weight: bold;
    }
    
    .question-actions {
      display: flex;
      gap: 0.5rem;
    }
    
    .question-text {
      font-weight: 600;
      color: #2c3e50;
      margin-bottom: 1rem;
      font-size: 1.1rem;
    }
    
    .options-display {
      display: grid;
      gap: 0.5rem;
    }
    
    .option {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.75rem;
      border-radius: 10px;
      background: #f8f9fa;
      transition: all 0.3s ease;
    }
    
    .option.correct {
      background: linear-gradient(45deg, #d4edda, #c3e6cb);
      color: #155724;
      font-weight: 600;
      border: 2px solid #28a745;
    }
    
    .option-label {
      background: #6c757d;
      color: white;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 0.8rem;
    }
    
    .option.correct .option-label {
      background: #28a745;
    }
    
    /* Empty States */
    .empty-state {
      text-align: center;
      padding: 3rem;
      color: #6c757d;
    }
    
    .empty-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }
    
    .empty-state h3 {
      margin-bottom: 0.5rem;
      color: #495057;
    }
    
    /* Notifications */
    .notification {
      position: fixed;
      top: 100px;
      right: 2rem;
      background: white;
      padding: 1rem 1.5rem;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transform: translateX(400px);
      transition: all 0.3s ease;
      z-index: 1000;
      border-left: 4px solid #28a745;
    }
    
    .notification.show {
      transform: translateX(0);
    }
    
    .notification.error {
      border-left-color: #dc3545;
    }
    
    .notification-icon {
      font-size: 1.2rem;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .hero-title {
        font-size: 2rem;
      }
      
      .stats-cards {
        grid-template-columns: 1fr;
      }
      
      .quiz-grid {
        grid-template-columns: 1fr;
      }
      
      .options-grid {
        grid-template-columns: 1fr;
      }
      
      .admin-tabs {
        flex-direction: column;
      }
      
      .notification {
        right: 1rem;
        left: 1rem;
        transform: translateY(-100px);
      }
      
      .notification.show {
        transform: translateY(0);
      }
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  activeTab = 'quizzes';
  quizzes: Quiz[] = [];
  users: (UserProfile & { selectedRole?: string })[] = [];
  selectedQuiz: Quiz | null = null;
  quizQuestions: any[] = [];
  questionCounts: { [quizId: number]: number } = {};
  viewingQuestions = false;
  isLoading = false;
  isUpdating = false;
  isEditing = false;
  editingQuizId: number | null = null;
  message = '';
  isError = false;

  newQuiz = {
    title: '',
    description: '',
    timeLimit: 30
  };

  newQuestion: QuestionDto = {
    questionText: '',
    option1: '',
    option2: '',
    option3: '',
    option4: '',
    correctAnswer: '',
    quizId: 0
  };

  constructor(
    private authService: AuthService,
    private router: Router,
    private quizService: QuizService,
    private questionService: QuestionService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadQuizzes();
    this.loadUsers();
  }

  loadUsers() {
    this.authService.getAllUsers().subscribe({
      next: (users) => {
        this.users = users.map(user => ({
          ...user,
          selectedRole: user.role
        }));
      },
      error: (error) => this.showMessage('Failed to load users', true)
    });
  }

  updateUserRole(user: UserProfile & { selectedRole?: string }) {
    if (!user.selectedRole || user.selectedRole === user.role) return;
    
    this.isUpdating = true;
    this.authService.updateUserRole(user.id, { role: user.selectedRole }).subscribe({
      next: (updatedUser) => {
        const index = this.users.findIndex(u => u.id === user.id);
        if (index !== -1) {
          this.users[index] = { ...updatedUser, selectedRole: updatedUser.role };
        }
        this.showMessage(`User role updated to ${updatedUser.role}`);
        this.isUpdating = false;
      },
      error: (error) => {
        this.showMessage('Failed to update user role', true);
        user.selectedRole = user.role;
        this.isUpdating = false;
      }
    });
  }

  deleteUser(user: UserProfile) {
    if (confirm(`Are you sure you want to delete user "${user.fullName}"? This action cannot be undone.`)) {
      this.isUpdating = true;
      this.authService.deleteUser(user.id).subscribe({
        next: () => {
          this.users = this.users.filter(u => u.id !== user.id);
          this.showMessage('User deleted successfully');
          this.isUpdating = false;
        },
        error: (error) => {
          this.showMessage('Failed to delete user', true);
          this.isUpdating = false;
        }
      });
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  loadQuizzes() {
    this.quizService.getAllQuizzes().subscribe({
      next: (quizzes) => {
        this.quizzes = quizzes;
        this.loadQuestionCounts();
      },
      error: (error) => this.showMessage('Failed to load quizzes', true)
    });
  }

  loadQuestionCounts() {
    this.quizzes.forEach(quiz => {
      this.questionService.getQuestionsByQuiz(quiz.id).subscribe({
        next: (questions) => {
          this.questionCounts[quiz.id] = questions.length;
          console.log(`Quiz ${quiz.id} has ${questions.length} questions`);
        },
        error: (error) => {
          console.error(`Error loading questions for quiz ${quiz.id}:`, error);
          this.questionCounts[quiz.id] = 0;
        }
      });
    });
  }

  getQuestionCount(quizId: number): number {
    return this.questionCounts[quizId] || 0;
  }

  viewQuizQuestions(quiz: Quiz) {
    this.selectedQuiz = quiz;
    this.viewingQuestions = true;
    this.activeTab = 'questions';
    
    this.questionService.getQuestionsByQuiz(quiz.id).subscribe({
      next: (questions) => {
        console.log('API Response:', questions);
        
        if (questions && questions.length > 0) {
          console.log('First question structure:', questions[0]);
          
          this.quizQuestions = questions.map(q => {
            return {
              id: q.id,
              questionText: q.questionText,
              option1: q.option1,
              option2: q.option2,
              option3: q.option3,
              option4: q.option4,
              correctAnswer: q.correctAnswer
            };
          });
        } else {
          this.quizQuestions = [];
        }
        
        console.log('Final mapped questions:', this.quizQuestions);
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error loading questions:', error);
        this.showMessage('Failed to load questions', true);
      }
    });
  }

  private mapCorrectAnswer(correctAnswer: string | undefined): string {
    // Return the correct answer as is since we're now using option1/2/3/4 consistently
    return correctAnswer || '';
  }

  editQuestion(question: any) {
    this.newQuestion = { ...question };
    this.viewingQuestions = false;
  }

  deleteQuestion(questionId: number) {
    if (confirm('Are you sure you want to delete this question?')) {
      this.questionService.deleteQuestion(questionId).subscribe({
        next: () => {
          this.quizQuestions = this.quizQuestions.filter(q => q.id !== questionId);
          this.loadQuestionCounts();
          this.showMessage('Question deleted successfully');
        },
        error: (error) => this.showMessage('Failed to delete question', true)
      });
    }
  }

  createQuiz() {
    if (!this.newQuiz.title || !this.newQuiz.description || !this.newQuiz.timeLimit) {
      this.showMessage('Please fill all fields', true);
      return;
    }

    this.isLoading = true;
    
    if (this.isEditing && this.editingQuizId) {
      this.quizService.updateQuiz(this.editingQuizId, this.newQuiz).subscribe({
        next: (updatedQuiz) => {
          const index = this.quizzes.findIndex(q => q.id === this.editingQuizId);
          if (index !== -1) {
            this.quizzes[index] = updatedQuiz;
          }
          this.resetForm();
          this.showMessage('Quiz updated successfully');
          this.isLoading = false;
        },
        error: (error) => {
          this.showMessage('Failed to update quiz', true);
          this.isLoading = false;
        }
      });
    } else {
      this.quizService.createQuiz(this.newQuiz).subscribe({
        next: (quiz) => {
          this.quizzes.push(quiz);
          this.resetForm();
          this.showMessage('Quiz created successfully');
          this.isLoading = false;
        },
        error: (error) => {
          this.showMessage('Failed to create quiz', true);
          this.isLoading = false;
        }
      });
    }
  }

  resetForm() {
    this.newQuiz = { title: '', description: '', timeLimit: 30 };
    this.isEditing = false;
    this.editingQuizId = null;
  }

  editQuiz(quiz: Quiz) {
    this.newQuiz = { ...quiz };
    this.isEditing = true;
    this.editingQuizId = quiz.id;
  }

  deleteQuiz(id: number) {
    if (confirm('Are you sure you want to delete this quiz?')) {
      this.quizService.deleteQuiz(id).subscribe({
        next: () => {
          this.quizzes = this.quizzes.filter(q => q.id !== id);
          this.showMessage('Quiz deleted successfully');
        },
        error: (error) => this.showMessage('Failed to delete quiz', true)
      });
    }
  }

  selectQuizForQuestions(quiz: Quiz) {
    this.selectedQuiz = quiz;
    this.newQuestion.quizId = quiz.id;
    this.viewingQuestions = false;
    this.activeTab = 'questions';
  }

  createQuestion() {
    if (!this.newQuestion.questionText || !this.newQuestion.option1 || !this.newQuestion.correctAnswer) {
      this.showMessage('Please fill all fields', true);
      return;
    }

    this.isLoading = true;
    this.questionService.createQuestion(this.newQuestion).subscribe({
      next: (question) => {
        this.newQuestion = {
          questionText: '',
          option1: '',
          option2: '',
          option3: '',
          option4: '',
          correctAnswer: '',
          quizId: this.selectedQuiz?.id || 0
        };
        this.showMessage('Question added successfully');
        this.loadQuestionCounts();
        this.isLoading = false;
      },
      error: (error) => {
        this.showMessage('Failed to add question', true);
        this.isLoading = false;
      }
    });
  }

  showMessage(msg: string, error = false) {
    this.message = msg;
    this.isError = error;
    setTimeout(() => this.message = '', 3000);
  }

  viewProfile() {
    this.router.navigate(['/profile']);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/home']);
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
    if (tab === 'quizzes') {
      this.viewingQuestions = false;
    }
  }

  getTotalQuestions(): number {
    return Object.values(this.questionCounts).reduce((sum, count) => sum + count, 0);
  }

  getActiveQuizzes(): number {
    return this.quizzes.filter(quiz => this.getQuestionCount(quiz.id) > 0).length;
  }
}
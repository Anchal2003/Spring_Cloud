import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { QuizService, QuizWithQuestions, QuizAttempt } from '../services/quiz.service';

@Component({
  selector: 'app-quiz',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="quiz-environment">
      <div class="background-animation">
        <div class="floating-particles">
          <div class="particle" *ngFor="let p of [1,2,3,4,5,6,7,8]" [style.animation-delay.s]="p * 0.5"></div>
        </div>
        <div class="geometric-shapes">
          <div class="shape triangle"></div>
          <div class="shape circle"></div>
          <div class="shape square"></div>
        </div>
      </div>

      <nav class="quiz-navbar">
        <div class="nav-content">
          <button (click)="goBack()" class="back-btn-3d">
            <span class="btn-icon">←</span>
            <span>Dashboard</span>
          </button>
          <div class="quiz-brand">
            <span class="brand-icon">🎯</span>
            <span class="brand-text">QuizApp</span>
          </div>
        </div>
      </nav>

      <div *ngIf="loading" class="loading-state">
        <div class="loading-3d">
          <div class="loading-cube">
            <div class="cube-face front">📚</div>
            <div class="cube-face back">📖</div>
            <div class="cube-face right">📝</div>
            <div class="cube-face left">📊</div>
            <div class="cube-face top">🎯</div>
            <div class="cube-face bottom">✨</div>
          </div>
          <h2 class="loading-text">Preparing Your Quiz...</h2>
          <div class="loading-dots">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>
      
      <div *ngIf="error" class="error-state">
        <div class="error-icon">⚠️</div>
        <h2>Oops! Something went wrong</h2>
        <p>{{ error }}</p>
        <button (click)="goBack()" class="retry-btn">Back to Dashboard</button>
      </div>

      <div *ngIf="!loading && !error && !showResult && questions.length > 0" class="quiz-interface">
        <div class="quiz-header-3d">
          <div class="quiz-title-container">
            <h1 class="quiz-title-3d">{{ quizTitle }}</h1>
            <div class="title-underline"></div>
          </div>
          
          <div class="progress-section">
            <div class="progress-info">
              <span class="question-counter">{{ currentQuestionIndex + 1 }} / {{ questions.length }}</span>
              <span class="progress-percentage">{{ getProgress().toFixed(0) }}%</span>
            </div>
            <div class="progress-bar-3d">
              <div class="progress-track">
                <div class="progress-fill" [style.width.%]="getProgress()"></div>
                <div class="progress-glow" [style.width.%]="getProgress()"></div>
              </div>
            </div>
          </div>
        </div>

        <div class="question-container-3d">
          <div class="question-card-3d" [style.animation-delay.ms]="100">
            <div class="card-header">
              <div class="question-number-badge">Q{{ currentQuestionIndex + 1 }}</div>
              <div class="difficulty-indicator">{{ getDifficulty() }}</div>
            </div>
            
            <div class="question-content">
              <h2 class="question-text">{{ getCurrentQuestion().text }}</h2>
            </div>
            
            <div class="options-grid">
              <div *ngFor="let option of getCurrentQuestion().options; let i = index" 
                   class="option-card-3d" 
                   [class.selected]="selectedAnswer === i"
                   [class.correct-preview]="false"
                   [style.animation-delay.ms]="(i + 1) * 150"
                   (click)="selectAnswer(i)">
                <div class="option-indicator">
                  <span class="option-letter">{{ getOptionLetter(i) }}</span>
                </div>
                <div class="option-content">
                  <span class="option-text">{{ option }}</span>
                </div>
                <div class="selection-ripple"></div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="navigation-3d">
          <button (click)="previousQuestion()" 
                  [disabled]="currentQuestionIndex === 0" 
                  class="nav-btn-3d prev-btn">
            <span class="btn-icon">←</span>
            <span>Previous</span>
          </button>
          
          <div class="question-dots">
            <div *ngFor="let q of questions; let i = index" 
                 class="dot" 
                 [class.active]="i === currentQuestionIndex"
                 [class.answered]="answers[i] !== -1">
            </div>
          </div>
          
          <button (click)="nextQuestion()" 
                  [disabled]="selectedAnswer === null" 
                  class="nav-btn-3d next-btn">
            <span>{{ isLastQuestion() ? 'Finish' : 'Next' }}</span>
            <span class="btn-icon">{{ isLastQuestion() ? '🏁' : '→' }}</span>
          </button>
        </div>
      </div>

      <div *ngIf="showResult" class="result-environment">
        <div class="celebration-animation">
          <div class="confetti" *ngFor="let c of [1,2,3,4,5,6,7,8,9,10]" [style.animation-delay.s]="c * 0.1"></div>
        </div>
        
        <div class="result-card-3d">
          <div class="result-header">
            <div class="trophy-icon">🏆</div>
            <h2 class="result-title">Quiz Completed!</h2>
            <p class="result-subtitle">Great job on finishing the quiz</p>
          </div>
          
          <div class="score-display-3d">
            <div class="score-circle-3d" [class.excellent]="getPercentage() >= 80" 
                 [class.good]="getPercentage() >= 60 && getPercentage() < 80"
                 [class.average]="getPercentage() < 60">
              <div class="score-inner">
                <span class="score-percentage">{{ getPercentage() }}%</span>
                <span class="score-label">Score</span>
              </div>
            </div>
            
            <div class="score-breakdown">
              <div class="score-stat">
                <div class="stat-value">{{ score }}</div>
                <div class="stat-label">Correct</div>
              </div>
              <div class="score-stat">
                <div class="stat-value">{{ questions.length - score }}</div>
                <div class="stat-label">Incorrect</div>
              </div>
              <div class="score-stat">
                <div class="stat-value">{{ questions.length }}</div>
                <div class="stat-label">Total</div>
              </div>
            </div>
          </div>
          
          <div class="result-actions">
            <button (click)="goBack()" class="dashboard-btn-3d">
              <span class="btn-icon">🏠</span>
              <span>Back to Dashboard</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .quiz-environment {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      position: relative;
      overflow-x: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .background-animation {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    }

    .floating-particles {
      position: absolute;
      width: 100%;
      height: 100%;
    }

    .particle {
      position: absolute;
      width: 4px;
      height: 4px;
      background: rgba(255, 255, 255, 0.6);
      border-radius: 50%;
      animation: floatParticle 8s linear infinite;
    }

    .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
    .particle:nth-child(2) { left: 20%; animation-delay: 1s; }
    .particle:nth-child(3) { left: 30%; animation-delay: 2s; }
    .particle:nth-child(4) { left: 40%; animation-delay: 3s; }
    .particle:nth-child(5) { left: 60%; animation-delay: 1.5s; }
    .particle:nth-child(6) { left: 70%; animation-delay: 2.5s; }
    .particle:nth-child(7) { left: 80%; animation-delay: 0.5s; }
    .particle:nth-child(8) { left: 90%; animation-delay: 3.5s; }

    @keyframes floatParticle {
      0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
    }

    .geometric-shapes {
      position: absolute;
      width: 100%;
      height: 100%;
    }

    .shape {
      position: absolute;
      opacity: 0.1;
      animation: rotateShape 20s linear infinite;
    }

    .triangle {
      width: 0;
      height: 0;
      border-left: 50px solid transparent;
      border-right: 50px solid transparent;
      border-bottom: 87px solid rgba(255, 255, 255, 0.2);
      top: 20%;
      left: 10%;
    }

    .circle {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      top: 60%;
      right: 15%;
      animation-delay: 5s;
    }

    .square {
      width: 80px;
      height: 80px;
      background: rgba(255, 255, 255, 0.2);
      top: 40%;
      right: 5%;
      animation-delay: 10s;
    }

    @keyframes rotateShape {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .quiz-navbar {
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.95), rgba(118, 75, 162, 0.95));
      backdrop-filter: blur(20px);
      padding: 1rem 0;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    }

    .nav-content {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2rem;
    }

    .back-btn-3d {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.3);
    }

    .back-btn-3d:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      background: rgba(255, 255, 255, 0.3);
    }

    .quiz-brand {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      color: white;
      font-size: 1.5rem;
      font-weight: 800;
    }

    .brand-icon {
      font-size: 2rem;
      animation: brandPulse 3s ease-in-out infinite;
    }

    @keyframes brandPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.1); }
    }

    .loading-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
      position: relative;
      z-index: 2;
    }

    .loading-3d {
      text-align: center;
      color: white;
    }

    .loading-cube {
      width: 100px;
      height: 100px;
      position: relative;
      margin: 0 auto 2rem;
      transform-style: preserve-3d;
      animation: rotateCube 3s linear infinite;
    }

    .cube-face {
      position: absolute;
      width: 100px;
      height: 100px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      background: rgba(255, 255, 255, 0.2);
      border: 2px solid rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(10px);
    }

    .front { transform: rotateY(0deg) translateZ(50px); }
    .back { transform: rotateY(180deg) translateZ(50px); }
    .right { transform: rotateY(90deg) translateZ(50px); }
    .left { transform: rotateY(-90deg) translateZ(50px); }
    .top { transform: rotateX(90deg) translateZ(50px); }
    .bottom { transform: rotateX(-90deg) translateZ(50px); }

    @keyframes rotateCube {
      0% { transform: rotateX(0deg) rotateY(0deg); }
      100% { transform: rotateX(360deg) rotateY(360deg); }
    }

    .loading-text {
      font-size: 2rem;
      margin-bottom: 1rem;
      background: linear-gradient(45deg, #fff, #f0f8ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .loading-dots {
      display: flex;
      gap: 0.5rem;
      justify-content: center;
    }

    .loading-dots span {
      width: 12px;
      height: 12px;
      background: white;
      border-radius: 50%;
      animation: bounce 1.4s ease-in-out infinite both;
    }

    .loading-dots span:nth-child(1) { animation-delay: -0.32s; }
    .loading-dots span:nth-child(2) { animation-delay: -0.16s; }

    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }

    .error-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
      text-align: center;
      color: white;
      position: relative;
      z-index: 2;
    }

    .error-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
    }

    .retry-btn {
      background: linear-gradient(45deg, #ff6b6b, #ee5a24);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 25px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 1rem;
    }

    .retry-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(255, 107, 107, 0.3);
    }

    .quiz-interface {
      padding: 1.5rem;
      max-width: 800px;
      margin: 0 auto;
      position: relative;
      z-index: 2;
    }

    .quiz-header-3d {
      text-align: center;
      margin-bottom: 3rem;
      animation: slideDown 0.8s ease-out;
    }

    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-50px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .quiz-title-container {
      margin-bottom: 2rem;
    }

    .quiz-title-3d {
      font-size: 2.5rem;
      font-weight: 800;
      color: white;
      margin-bottom: 0.5rem;
      text-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    .title-underline {
      width: 100px;
      height: 4px;
      background: linear-gradient(45deg, #ffd700, #ffed4e);
      margin: 0 auto;
      border-radius: 2px;
    }

    .progress-section {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 1.5rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .progress-info {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
      color: white;
      font-weight: 600;
    }

    .progress-bar-3d {
      position: relative;
    }

    .progress-track {
      width: 100%;
      height: 12px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 6px;
      overflow: hidden;
      position: relative;
    }

    .progress-fill {
      height: 100%;
      background: linear-gradient(45deg, #4ecdc4, #44a08d);
      border-radius: 6px;
      transition: width 0.5s ease;
      position: relative;
    }

    .progress-glow {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      background: linear-gradient(45deg, rgba(78, 205, 196, 0.5), rgba(68, 160, 141, 0.5));
      border-radius: 6px;
      filter: blur(4px);
      transition: width 0.5s ease;
    }

    .question-container-3d {
      margin-bottom: 2rem;
    }

    .question-card-3d {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 16px;
      padding: 1.4rem;
      box-shadow: 0 20px 60px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      transition: all 0.4s ease;
      animation: cardSlideUp 0.8s ease-out;
    }

    @keyframes cardSlideUp {
      from { opacity: 0; transform: translateY(50px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .question-card-3d:hover {
      transform: translateY(-5px);
      box-shadow: 0 25px 80px rgba(0,0,0,0.15);
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.2rem;
    }

    .question-number-badge {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      padding: 0.6rem 1.2rem;
      border-radius: 16px;
      font-weight: 700;
      font-size: 0.95rem;
    }

    .difficulty-indicator {
      background: linear-gradient(45deg, #28a745, #20c997);
      color: white;
      padding: 0.4rem 0.8rem;
      border-radius: 12px;
      font-size: 0.8rem;
      font-weight: 600;
    }

    .question-content {
      margin-bottom: 1.2rem;
    }

    .question-text {
      font-size: 1.25rem;
      font-weight: 600;
      color: #2c3e50;
      line-height: 1.4;
      text-align: center;
    }

    .options-grid {
      display: grid;
      gap: 0.8rem;
    }

    .option-card-3d {
      background: white;
      border: 2px solid #e9ecef;
      border-radius: 10px;
      padding: 0.8rem;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      gap: 0.7rem;
      animation: optionSlideIn 0.6s ease-out both;
    }

    @keyframes optionSlideIn {
      from { opacity: 0; transform: translateX(-30px); }
      to { opacity: 1; transform: translateX(0); }
    }

    .option-card-3d:hover {
      transform: translateY(-3px) scale(1.02);
      border-color: #667eea;
      box-shadow: 0 10px 30px rgba(102, 126, 234, 0.2);
    }

    .option-card-3d.selected {
      border-color: #667eea;
      background: linear-gradient(45deg, #e3f2fd, #f3e5f5);
      transform: translateY(-3px) scale(1.02);
      box-shadow: 0 15px 40px rgba(102, 126, 234, 0.3);
    }

    .option-indicator {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(45deg, #667eea, #764ba2);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 1rem;
      flex-shrink: 0;
    }

    .option-content {
      flex: 1;
    }

    .option-text {
      font-size: 1rem;
      font-weight: 500;
      color: #2c3e50;
    }

    .selection-ripple {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background: rgba(102, 126, 234, 0.3);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: all 0.6s ease;
    }

    .option-card-3d:active .selection-ripple {
      width: 300px;
      height: 300px;
    }

    .navigation-3d {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 1.5rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .nav-btn-3d {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 1rem 2rem;
      border: none;
      border-radius: 15px;
      cursor: pointer;
      font-weight: 600;
      font-size: 1.1rem;
      transition: all 0.3s ease;
    }

    .prev-btn {
      background: rgba(255, 255, 255, 0.2);
      color: white;
    }

    .next-btn {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
    }

    .nav-btn-3d:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .nav-btn-3d:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .question-dots {
      display: flex;
      gap: 0.5rem;
    }

    .dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.3);
      transition: all 0.3s ease;
    }

    .dot.active {
      background: #ffd700;
      transform: scale(1.3);
    }

    .dot.answered {
      background: #4ecdc4;
    }

    .result-environment {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      position: relative;
      z-index: 2;
    }

    .celebration-animation {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }

    .confetti {
      position: absolute;
      width: 10px;
      height: 10px;
      background: #ffd700;
      animation: confettiFall 3s linear infinite;
    }

    .confetti:nth-child(odd) { background: #ff6b6b; }
    .confetti:nth-child(3n) { background: #4ecdc4; }
    .confetti:nth-child(4n) { background: #45b7d1; }
    .confetti:nth-child(5n) { background: #96ceb4; }

    .confetti:nth-child(1) { left: 10%; }
    .confetti:nth-child(2) { left: 20%; }
    .confetti:nth-child(3) { left: 30%; }
    .confetti:nth-child(4) { left: 40%; }
    .confetti:nth-child(5) { left: 50%; }
    .confetti:nth-child(6) { left: 60%; }
    .confetti:nth-child(7) { left: 70%; }
    .confetti:nth-child(8) { left: 80%; }
    .confetti:nth-child(9) { left: 90%; }
    .confetti:nth-child(10) { left: 95%; }

    @keyframes confettiFall {
      0% { transform: translateY(-100vh) rotate(0deg); }
      100% { transform: translateY(100vh) rotate(720deg); }
    }

    .result-card-3d {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 30px;
      padding: 3rem;
      box-shadow: 0 30px 80px rgba(0,0,0,0.2);
      border: 1px solid rgba(255,255,255,0.3);
      text-align: center;
      max-width: 500px;
      animation: resultSlideUp 1s ease-out;
    }

    @keyframes resultSlideUp {
      from { opacity: 0; transform: translateY(100px) scale(0.8); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }

    .result-header {
      margin-bottom: 2rem;
    }

    .trophy-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      animation: trophyBounce 2s ease-in-out infinite;
    }

    @keyframes trophyBounce {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
    }

    .result-title {
      font-size: 2.5rem;
      font-weight: 800;
      color: #2c3e50;
      margin-bottom: 0.5rem;
    }

    .result-subtitle {
      color: #7f8c8d;
      font-size: 1.1rem;
    }

    .score-display-3d {
      margin-bottom: 2rem;
    }

    .score-circle-3d {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 2rem;
      position: relative;
      animation: scoreReveal 1.5s ease-out 0.5s both;
    }

    .score-circle-3d.excellent {
      background: linear-gradient(45deg, #d4edda, #c3e6cb);
      border: 4px solid #28a745;
    }

    .score-circle-3d.good {
      background: linear-gradient(45deg, #fff3cd, #ffeaa7);
      border: 4px solid #ffc107;
    }

    .score-circle-3d.average {
      background: linear-gradient(45deg, #f8d7da, #fab1a0);
      border: 4px solid #dc3545;
    }

    @keyframes scoreReveal {
      from { transform: scale(0) rotate(-180deg); }
      to { transform: scale(1) rotate(0deg); }
    }

    .score-inner {
      text-align: center;
    }

    .score-percentage {
      font-size: 2.5rem;
      font-weight: 800;
      color: #2c3e50;
      display: block;
    }

    .score-label {
      font-size: 1rem;
      color: #7f8c8d;
      font-weight: 600;
    }

    .score-breakdown {
      display: flex;
      justify-content: space-around;
      margin-bottom: 2rem;
    }

    .score-stat {
      text-align: center;
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: #2c3e50;
    }

    .stat-label {
      font-size: 0.9rem;
      color: #7f8c8d;
      font-weight: 600;
    }

    .dashboard-btn-3d {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 25px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .dashboard-btn-3d:hover {
      transform: translateY(-3px);
      box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
    }

    @media (max-width: 768px) {
      .quiz-interface { padding: 1rem; }
      .question-card-3d { padding: 1.5rem; }
      .quiz-title-3d { font-size: 2rem; }
      .navigation-3d { flex-direction: column; gap: 1rem; }
      .question-dots { order: -1; }
      .result-card-3d { padding: 2rem; margin: 1rem; }
    }
  `]
})
export class QuizComponent implements OnInit {
  currentQuestionIndex = 0;
  selectedAnswer: number | null = null;
  answers: number[] = [];
  showResult = false;
  score = 0;
  loading = true;
  error = '';
  quizTitle = 'Quiz';
  quizId = 0;
  apiQuiz: QuizWithQuestions | null = null;
  questions: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private quizService: QuizService
  ) {}

  ngOnInit() {
    this.quizId = +this.route.snapshot.params['id'];
    if (this.quizId > 0) {
      this.loadQuiz();
    } else {
      this.loadSampleQuiz();
    }
  }

  loadQuiz() {
    this.quizService.getQuizWithQuestions(this.quizId).subscribe({
      next: (quiz) => {
        if (quiz?.questions?.length) {
          this.apiQuiz = quiz;
          this.quizTitle = quiz.title;
          this.convertApiQuestions(quiz.questions);
          this.loading = false;
        } else {
          this.loadSampleQuiz();
        }
      },
      error: (error) => {
        console.log('API failed, loading sample quiz');
        this.loadSampleQuiz();
      }
    });
  }

  loadSampleQuiz() {
    this.questions = [
      {
        id: 1,
        text: "What is the capital of France?",
        options: ["London", "Berlin", "Paris", "Madrid"],
        correct: 2
      },
      {
        id: 2,
        text: "Which planet is known as the Red Planet?",
        options: ["Venus", "Mars", "Jupiter", "Saturn"],
        correct: 1
      },
      {
        id: 3,
        text: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        correct: 1
      }
    ];
    this.answers = new Array(this.questions.length).fill(-1);
    this.quizTitle = 'Sample Quiz';
    this.loading = false;
  }

  convertApiQuestions(apiQuestions: any[]) {
    console.log('=== CONVERTING API QUESTIONS ===');
    
    this.questions = apiQuestions.map(q => {
      const allOptions = [q.option1, q.option2, q.option3, q.option4];
      const filteredOptions = allOptions.filter(opt => opt?.trim());
      const correctIndexInFiltered = filteredOptions.findIndex(opt => opt === q.correctAnswer);
      
      console.log(`\nQuestion ID ${q.id}: "${q.questionText}"`);
      console.log(`All options:`, allOptions);
      console.log(`Filtered options:`, filteredOptions);
      console.log(`Correct answer: "${q.correctAnswer}"`);
      console.log(`Correct index in filtered: ${correctIndexInFiltered}`);
      
      return {
        id: q.id,
        text: q.questionText,
        options: filteredOptions,
        correct: correctIndexInFiltered
      };
    });
    this.answers = new Array(this.questions.length).fill(-1);
  }

  getCurrentQuestion() {
    return this.questions[this.currentQuestionIndex];
  }

  selectAnswer(optionIndex: number) {
    this.selectedAnswer = optionIndex;
    this.answers[this.currentQuestionIndex] = optionIndex;
  }

  nextQuestion() {
    if (this.isLastQuestion()) {
      this.finishQuiz();
    } else {
      this.currentQuestionIndex++;
      this.selectedAnswer = this.answers[this.currentQuestionIndex] >= 0 ? this.answers[this.currentQuestionIndex] : null;
    }
  }

  previousQuestion() {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
      this.selectedAnswer = this.answers[this.currentQuestionIndex] >= 0 ? this.answers[this.currentQuestionIndex] : null;
    }
  }

  isLastQuestion(): boolean {
    return this.currentQuestionIndex === this.questions.length - 1;
  }

  getProgress(): number {
    return ((this.currentQuestionIndex + 1) / this.questions.length) * 100;
  }

  finishQuiz() {
    if (this.apiQuiz) {
      this.submitToAPI();
    } else {
      this.calculateLocalScore();
    }
  }

  submitToAPI() {
    const apiAnswers: { [questionId: number]: string } = {};
    
    for (let i = 0; i < this.questions.length; i++) {
      const question = this.questions[i];
      const answerIndex = this.answers[i];
      
      if (answerIndex >= 0) {
        // Convert answer index to option label (option1, option2, etc.)
        const optionLabels = ['option1', 'option2', 'option3', 'option4'];
        apiAnswers[question.id] = optionLabels[answerIndex];
      }
    }
    
    this.quizService.submitQuiz(this.quizId, { answers: apiAnswers }).subscribe({
      next: (result) => {
        this.score = result.score;
        this.showResult = true;
      },
      error: (error) => {
        console.error('API submission failed:', error);
        this.calculateLocalScore();
      }
    });
  }

  calculateLocalScore() {
    this.score = 0;
    
    for (let i = 0; i < this.questions.length; i++) {
      const userAnswer = this.answers[i];
      const correctAnswer = this.questions[i].correct;
      
      if (userAnswer === correctAnswer) {
        this.score++;
      }
    }
    
    this.showResult = true;
  }

  getPercentage(): number {
    return Math.round((this.score / this.questions.length) * 100);
  }

  getDifficulty(): string {
    const totalQuestions = this.questions.length;
    if (totalQuestions <= 5) return 'Easy';
    if (totalQuestions <= 10) return 'Medium';
    return 'Hard';
  }

  getOptionLetter(index: number): string {
    return String.fromCharCode(65 + index); // A, B, C, D
  }

  goBack() {
    this.router.navigate(['/user-dashboard'], { 
      queryParams: { refresh: 'true' } 
    });
  }
}
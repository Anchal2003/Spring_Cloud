import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, timeout, retry, catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export interface Quiz {
  id: number;
  title: string;
  description: string;
  timeLimit: number;
}

export interface Question {
  id: number;
  questionText: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctAnswer?: string;
  quizId?: number;
}

export interface QuizWithQuestions {
  id: number;
  title: string;
  description: string;
  timeLimit: number;
  questions: Question[];
}

export interface QuizSubmission {
  answers: { [questionId: number]: string };
}

export interface QuizAttempt {
  id: number;
  userId: number;
  quizId: number;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  attemptDate: string;
  answers: { [questionId: number]: string };
}

@Injectable({
  providedIn: 'root'
})
export class QuizService {
  private apiUrl = 'http://localhost:8080';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    const username = this.authService.getUsername();
    
    if (!token || !this.authService.isAuthenticated()) {
      throw new Error('User not authenticated');
    }
    
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'X-Username': username || '',
      'Content-Type': 'application/json'
    });
  }

  // User endpoints
  getAvailableQuizzes(): Observable<Quiz[]> {
    try {
      return this.http.get<Quiz[]>(`${this.apiUrl}/user/quizzes`, { headers: this.getHeaders() })
        .pipe(
          timeout(15000),
          catchError(error => {
            console.error('Quizzes API Error:', error);
            let errorMessage = 'Failed to load quizzes';
            
            if (error.status === 401 || error.status === 403) {
              errorMessage = 'Authentication failed. Please login again.';
            } else if (error.status === 0) {
              errorMessage = 'Cannot connect to server. Please check your connection.';
            }
            
            return throwError(() => ({ ...error, message: errorMessage }));
          })
        );
    } catch (authError) {
      return throwError(() => ({ message: 'Authentication required. Please login.' }));
    }
  }

  getQuizWithQuestions(id: number): Observable<QuizWithQuestions> {
    console.log('QuizService: Getting quiz with ID:', id);
    
    try {
      const headers = this.getHeaders();
      console.log('QuizService: Headers created successfully');
      
      const url = `${this.apiUrl}/user/quizzes/${id}`;
      console.log('QuizService: Making request to:', url);
      
      return this.http.get<QuizWithQuestions>(url, { headers })
        .pipe(
          timeout(8000),
          catchError(error => {
            console.error('QuizService: API Error details:', {
              status: error.status,
              statusText: error.statusText,
              url: error.url,
              message: error.message
            });
            
            let errorMessage = 'Failed to load quiz';
            
            if (error.status === 404) {
              errorMessage = 'Quiz not found';
            } else if (error.status === 401 || error.status === 403) {
              errorMessage = 'Authentication failed. Please login again.';
            } else if (error.status === 0) {
              errorMessage = 'Cannot connect to server. Check if backend is running on port 8080.';
            } else if (error.name === 'TimeoutError') {
              errorMessage = 'Request timed out. Backend may be slow or unresponsive.';
            }
            
            return throwError(() => ({ ...error, message: errorMessage }));
          })
        );
    } catch (authError) {
      console.error('QuizService: Auth error:', authError);
      return throwError(() => ({ message: 'Authentication required. Please login.' }));
    }
  }

  submitQuiz(quizId: number, submission: QuizSubmission): Observable<QuizAttempt> {
    return this.http.post<QuizAttempt>(`${this.apiUrl}/user/quizzes/${quizId}/submit`, submission, { headers: this.getHeaders() })
      .pipe(
        timeout(5000),
        catchError(error => {
          console.error('Submit Quiz API Error:', error);
          return throwError(() => ({ ...error, message: 'Failed to submit quiz' }));
        })
      );
  }

  getUserAttempts(): Observable<QuizAttempt[]> {
    return this.http.get<QuizAttempt[]>(`${this.apiUrl}/user/quizzes/attempts`, { headers: this.getHeaders() });
  }

  getAttempt(attemptId: number): Observable<QuizAttempt> {
    return this.http.get<QuizAttempt>(`${this.apiUrl}/user/quizzes/attempts/${attemptId}`, { headers: this.getHeaders() });
  }

  // Admin endpoints
  createQuiz(quiz: Partial<Quiz>): Observable<Quiz> {
    return this.http.post<Quiz>(`${this.apiUrl}/admin/quizzes`, quiz, { headers: this.getHeaders() });
  }

  updateQuiz(id: number, quiz: Partial<Quiz>): Observable<Quiz> {
    return this.http.put<Quiz>(`${this.apiUrl}/admin/quizzes/${id}`, quiz, { headers: this.getHeaders() });
  }

  deleteQuiz(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/admin/quizzes/${id}`, { headers: this.getHeaders() });
  }

  getAllQuizzes(): Observable<Quiz[]> {
    return this.http.get<Quiz[]>(`${this.apiUrl}/admin/quizzes`, { headers: this.getHeaders() });
  }

  getAdminQuizWithQuestions(id: number): Observable<QuizWithQuestions> {
    return this.http.get<QuizWithQuestions>(`${this.apiUrl}/admin/quizzes/${id}`, { headers: this.getHeaders() });
  }
}
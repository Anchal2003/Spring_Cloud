import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [RouterLink, CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit, OnDestroy {
  stats = {
    users: 0,
    topics: 0,
    successRate: 0,
    availability: '24/7'
  };

  private animationInterval: any;

  ngOnInit() {
    this.animateStats();
    this.addScrollAnimations();
  }

  ngOnDestroy() {
    if (this.animationInterval) {
      clearInterval(this.animationInterval);
    }
  }

  private animateStats() {
    const targets = {
      users: 10000,
      topics: 500,
      successRate: 95
    };

    const duration = 2000; // 2 seconds
    const steps = 60;
    const stepDuration = duration / steps;

    let currentStep = 0;

    this.animationInterval = setInterval(() => {
      currentStep++;
      const progress = currentStep / steps;
      
      this.stats.users = Math.floor(targets.users * progress);
      this.stats.topics = Math.floor(targets.topics * progress);
      this.stats.successRate = Math.floor(targets.successRate * progress);

      if (currentStep >= steps) {
        clearInterval(this.animationInterval);
        this.stats.users = targets.users;
        this.stats.topics = targets.topics;
        this.stats.successRate = targets.successRate;
      }
    }, stepDuration);
  }

  private addScrollAnimations() {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe elements when they come into view
    setTimeout(() => {
      const elementsToAnimate = document.querySelectorAll('.feature-card, .stat-item');
      elementsToAnimate.forEach(el => observer.observe(el));
    }, 100);
  }

  formatNumber(num: number): string {
    if (num >= 1000) {
      return (num / 1000).toFixed(0) + 'K+';
    }
    return num.toString();
  }
}
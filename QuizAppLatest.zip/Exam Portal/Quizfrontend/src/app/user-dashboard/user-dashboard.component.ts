import { Component, OnInit } from '@angular/core';
import { RouterLink, Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { QuizService, Quiz, QuizWithQuestions, QuizAttempt } from '../services/quiz.service';

@Component({
  selector: 'app-user-dashboard',
  imports: [RouterLink, CommonModule, FormsModule],
  template: `
    <div class="dashboard-container">
      <div class="background-animation">
        <div class="floating-shapes">
          <div class="shape shape-1"></div>
          <div class="shape shape-2"></div>
          <div class="shape shape-3"></div>
          <div class="shape shape-4"></div>
          <div class="shape shape-5"></div>
        </div>
      </div>

      <nav class="navbar">
        <div class="nav-container">
          <div class="nav-logo">
            <a routerLink="/home">
              <span class="logo-icon">🎯</span>
              <span class="logo-text">QuizApp</span>
            </a>
          </div>
          <div class="nav-user">
            <div class="user-avatar">
              <span class="avatar-icon">👤</span>
            </div>
            <div class="user-info">
              <span class="welcome-text">Welcome back,</span>
              <span class="username">{{ username }}</span>
            </div>
            <div class="nav-actions">
              <button (click)="viewProfile()" class="nav-btn profile-btn">
                <span class="btn-icon">👤</span>
                <span>Profile</span>
              </button>
              <button (click)="logout()" class="nav-btn logout-btn">
                <span class="btn-icon">🚪</span>
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div class="hero-section">
        <div class="hero-content">
          <div class="hero-3d-element">
            <div class="floating-quiz-icon">📚</div>
          </div>
          <h1 class="hero-title">Your Learning Journey</h1>
          <p class="hero-subtitle">Explore quizzes, track progress, and achieve your goals</p>
        </div>
      </div>
      
      <main class="dashboard-content">
        <div class="stats-overview">
          <div class="stat-card" [style.animation-delay.ms]="0">
            <div class="stat-icon">📊</div>
            <div class="stat-value">{{ availableQuizzes.length }}</div>
            <div class="stat-label">Available Quizzes</div>
          </div>
          <div class="stat-card" [style.animation-delay.ms]="150">
            <div class="stat-icon">✅</div>
            <div class="stat-value">{{ myAttempts.length }}</div>
            <div class="stat-label">Completed</div>
          </div>
          <div class="stat-card" [style.animation-delay.ms]="300">
            <div class="stat-icon">🎯</div>
            <div class="stat-value">{{ getAverageScore() }}%</div>
            <div class="stat-label">Average Score</div>
          </div>
        </div>
        
        <div class="user-tabs">
          <button (click)="activeTab = 'quizzes'" [class.active]="activeTab === 'quizzes'" class="tab-btn">
            <span class="tab-icon">📝</span>
            <span>Available Quizzes</span>
          </button>
          <button (click)="activeTab = 'attempts'" [class.active]="activeTab === 'attempts'" class="tab-btn">
            <span class="tab-icon">📈</span>
            <span>My Progress</span>
          </button>
        </div>

        <!-- Available Quizzes -->
        <div *ngIf="activeTab === 'quizzes'" class="tab-content fade-in">
          <div *ngIf="isLoading" class="loading-state">
            <div class="loading-animation">
              <div class="loading-spinner"></div>
              <div class="loading-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
            <h2>Loading Quizzes...</h2>
          </div>
          
          <div *ngIf="!isLoading && availableQuizzes.length === 0" class="empty-state">
            <div class="empty-icon">📝</div>
            <h3>No Quizzes Available</h3>
            <p>Check back later for new quizzes!</p>
          </div>
          
          <div *ngIf="!isLoading && availableQuizzes.length > 0" class="quiz-grid">
            <div *ngFor="let quiz of availableQuizzes; let i = index" 
                 class="quiz-card-3d" 
                 [style.animation-delay.ms]="i * 100">
              <div class="card-glow"></div>
              <div class="card-header">
                <div class="quiz-icon">🎯</div>
                <div class="difficulty-badge">{{ getDifficulty(quiz) }}</div>
              </div>
              <div class="card-content">
                <h3 class="quiz-title">{{ quiz.title }}</h3>
                <p class="quiz-description">{{ quiz.description }}</p>
                <div class="quiz-meta">
                  <div class="meta-item">
                    <span class="meta-icon">⏱️</span>
                    <span>{{ quiz.timeLimit || 15 }} min</span>
                  </div>
                  <div class="meta-item">
                    <span class="meta-icon">❓</span>
                    <span>{{ getQuestionCount(quiz) }} questions</span>
                  </div>
                </div>
              </div>
              <div class="card-footer">
                <button (click)="startQuiz(quiz)" class="start-btn-3d">
                  <span class="btn-content">
                    <span class="btn-icon">🚀</span>
                    <span>Start Quiz</span>
                  </span>
                  <div class="btn-ripple"></div>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- My Attempts -->
        <div *ngIf="activeTab === 'attempts'" class="tab-content fade-in">
          <div *ngIf="myAttempts.length === 0" class="empty-state">
            <div class="empty-icon">📈</div>
            <h3>No Attempts Yet</h3>
            <p>Start taking quizzes to see your progress here!</p>
          </div>
          
          <div *ngIf="myAttempts.length > 0" class="attempts-grid">
            <div *ngFor="let attempt of myAttempts; let i = index" 
                 class="attempt-card-3d" 
                 [style.animation-delay.ms]="i * 100">
              <div class="attempt-header">
                <div class="attempt-icon">📊</div>
                <div class="attempt-date">{{ formatDate(attempt.attemptDate) }}</div>
              </div>
              <h3 class="attempt-title">{{ attempt.quizTitle }}</h3>
              <div class="score-display">
                <div class="score-circle" [class.high]="(attempt.percentage || 0) >= 70" 
                     [class.medium]="(attempt.percentage || 0) >= 50 && (attempt.percentage || 0) < 70" 
                     [class.low]="(attempt.percentage || 0) < 50">
                  <span class="score-percentage">{{ (attempt.percentage || 0).toFixed(0) }}%</span>
                </div>
                <div class="score-details">
                  <div class="score-fraction">{{ attempt.score }}/{{ attempt.totalQuestions }}</div>
                  <div class="score-label">Correct Answers</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div *ngIf="message" class="notification" [class.error]="isError" [class.show]="message">
          <div class="notification-icon">{{ isError ? '❌' : '✅' }}</div>
          <span>{{ message }}</span>
        </div>
      </main>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .dashboard-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      position: relative;
      overflow-x: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .background-animation {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    }

    .floating-shapes {
      position: relative;
      width: 100%;
      height: 100%;
    }

    .shape {
      position: absolute;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      animation: floatShape 8s ease-in-out infinite;
    }

    .shape-1 { width: 80px; height: 80px; top: 10%; left: 5%; animation-delay: 0s; }
    .shape-2 { width: 120px; height: 120px; top: 70%; left: 85%; animation-delay: 2s; }
    .shape-3 { width: 60px; height: 60px; top: 30%; left: 90%; animation-delay: 4s; }
    .shape-4 { width: 100px; height: 100px; top: 80%; left: 10%; animation-delay: 1s; }
    .shape-5 { width: 40px; height: 40px; top: 50%; left: 3%; animation-delay: 3s; }

    @keyframes floatShape {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-30px) rotate(180deg); }
    }

    .navbar {
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.95), rgba(118, 75, 162, 0.95));
      backdrop-filter: blur(20px);
      padding: 1rem 0;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2rem;
    }

    .nav-logo a {
      color: #fff;
      font-size: 1.8rem;
      font-weight: 800;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transition: all 0.4s ease;
    }

    .nav-logo a:hover {
      transform: scale(1.1);
      filter: drop-shadow(0 0 20px rgba(255,255,255,0.5));
    }

    .logo-icon {
      font-size: 2.2rem;
      animation: logoFloat 3s ease-in-out infinite;
    }

    @keyframes logoFloat {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-8px) rotate(5deg); }
    }

    .nav-user {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .user-avatar {
      width: 50px;
      height: 50px;
      background: linear-gradient(45deg, #ff6b6b, #feca57);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      animation: avatarPulse 2s ease-in-out infinite;
    }

    @keyframes avatarPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.1); }
    }

    .user-info {
      display: flex;
      flex-direction: column;
      color: white;
    }

    .welcome-text {
      font-size: 0.9rem;
      opacity: 0.8;
    }

    .username {
      font-size: 1.1rem;
      font-weight: 600;
    }

    .nav-actions {
      display: flex;
      gap: 0.75rem;
    }

    .nav-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.25rem;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.2);
    }

    .profile-btn {
      background: rgba(255, 255, 255, 0.2);
      color: white;
    }

    .logout-btn {
      background: linear-gradient(45deg, #ff6b6b, #ee5a24);
      color: white;
    }

    .nav-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .hero-section {
      padding: 3rem 2rem;
      text-align: center;
      position: relative;
      z-index: 2;
    }

    .hero-content {
      max-width: 800px;
      margin: 0 auto;
      position: relative;
    }

    .hero-3d-element {
      margin-bottom: 2rem;
    }

    .floating-quiz-icon {
      font-size: 4rem;
      animation: floatIcon 4s ease-in-out infinite;
      filter: drop-shadow(0 10px 20px rgba(0,0,0,0.2));
    }

    @keyframes floatIcon {
      0%, 100% { transform: translateY(0px) rotateY(0deg); }
      50% { transform: translateY(-20px) rotateY(180deg); }
    }

    .hero-title {
      font-size: 3rem;
      font-weight: 800;
      color: white;
      margin-bottom: 1rem;
      background: linear-gradient(45deg, #fff, #f0f8ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .hero-subtitle {
      font-size: 1.2rem;
      color: rgba(255, 255, 255, 0.9);
      margin-bottom: 2rem;
    }

    .dashboard-content {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
      position: relative;
      z-index: 2;
    }

    .stats-overview {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 2rem;
      margin-bottom: 3rem;
    }

    .stat-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 2rem;
      text-align: center;
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      animation: cardSlideUp 0.6s ease-out both;
    }

    @keyframes cardSlideUp {
      from { opacity: 0; transform: translateY(50px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .stat-card:hover {
      transform: translateY(-10px) scale(1.05);
      box-shadow: 0 25px 60px rgba(0,0,0,0.15);
    }

    .stat-icon {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      animation: iconBounce 2s ease-in-out infinite;
    }

    @keyframes iconBounce {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
    }

    .stat-value {
      font-size: 2.5rem;
      font-weight: 800;
      color: #2c3e50;
      margin-bottom: 0.5rem;
    }

    .stat-label {
      color: #7f8c8d;
      font-weight: 600;
    }

    .user-tabs {
      display: flex;
      gap: 1rem;
      margin-bottom: 2rem;
      justify-content: center;
    }

    .tab-btn {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 1rem 2rem;
      border: none;
      background: rgba(255, 255, 255, 0.9);
      cursor: pointer;
      border-radius: 15px;
      font-weight: 600;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      backdrop-filter: blur(10px);
    }

    .tab-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .tab-btn.active {
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      transform: translateY(-2px);
    }

    .tab-icon {
      font-size: 1.2rem;
    }

    .fade-in {
      animation: fadeIn 0.6s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .loading-state, .empty-state {
      text-align: center;
      padding: 4rem 2rem;
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      color: #2c3e50;
    }

    .loading-animation {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    .loading-spinner {
      width: 60px;
      height: 60px;
      border: 4px solid rgba(102, 126, 234, 0.2);
      border-top: 4px solid #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .loading-dots {
      display: flex;
      gap: 0.5rem;
    }

    .loading-dots span {
      width: 8px;
      height: 8px;
      background: #667eea;
      border-radius: 50%;
      animation: bounce 1.4s ease-in-out infinite both;
    }

    .loading-dots span:nth-child(1) { animation-delay: -0.32s; }
    .loading-dots span:nth-child(2) { animation-delay: -0.16s; }

    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }

    .empty-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      opacity: 0.6;
    }

    .quiz-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
      gap: 2rem;
    }

    .quiz-card-3d {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 0;
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      position: relative;
      overflow: hidden;
      animation: cardSlideUp 0.6s ease-out both;
    }

    .quiz-card-3d:hover {
      transform: translateY(-10px) rotateX(5deg) rotateY(5deg);
      box-shadow: 0 25px 60px rgba(0,0,0,0.15);
    }

    .card-glow {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(45deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    .quiz-card-3d:hover .card-glow {
      opacity: 1;
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem 1.5rem 0;
    }

    .quiz-icon {
      font-size: 2.5rem;
      animation: iconBounce 2s ease-in-out infinite;
    }

    .difficulty-badge {
      background: linear-gradient(45deg, #28a745, #20c997);
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 15px;
      font-size: 0.8rem;
      font-weight: 600;
    }

    .card-content {
      padding: 1.5rem;
    }

    .quiz-title {
      font-size: 1.4rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 0.75rem;
      line-height: 1.3;
    }

    .quiz-description {
      color: #7f8c8d;
      line-height: 1.6;
      margin-bottom: 1.5rem;
    }

    .quiz-meta {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .meta-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(102, 126, 234, 0.1);
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.9rem;
    }

    .card-footer {
      padding: 0 1.5rem 1.5rem;
    }

    .start-btn-3d {
      width: 100%;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 15px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }

    .start-btn-3d:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
    }

    .btn-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      position: relative;
      z-index: 2;
    }

    .btn-ripple {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background: rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: all 0.6s ease;
    }

    .start-btn-3d:active .btn-ripple {
      width: 300px;
      height: 300px;
    }

    .attempts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 2rem;
    }

    .attempt-card-3d {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 2rem;
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      transition: all 0.4s ease;
      animation: cardSlideUp 0.6s ease-out both;
    }

    .attempt-card-3d:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 50px rgba(0,0,0,0.15);
    }

    .attempt-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .attempt-icon {
      font-size: 2rem;
    }

    .attempt-date {
      font-size: 0.9rem;
      color: #7f8c8d;
    }

    .attempt-title {
      font-size: 1.3rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 1.5rem;
    }

    .score-display {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .score-circle {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      position: relative;
    }

    .score-circle.high {
      background: linear-gradient(45deg, #d4edda, #c3e6cb);
      color: #155724;
    }

    .score-circle.medium {
      background: linear-gradient(45deg, #fff3cd, #ffeaa7);
      color: #856404;
    }

    .score-circle.low {
      background: linear-gradient(45deg, #f8d7da, #fab1a0);
      color: #721c24;
    }

    .score-percentage {
      font-size: 1.2rem;
    }

    .score-details {
      display: flex;
      flex-direction: column;
    }

    .score-fraction {
      font-size: 1.5rem;
      font-weight: bold;
      color: #2c3e50;
    }

    .score-label {
      color: #7f8c8d;
      font-size: 0.9rem;
    }

    .notification {
      position: fixed;
      top: 100px;
      right: 2rem;
      background: white;
      padding: 1rem 1.5rem;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      display: flex;
      align-items: center;
      gap: 0.75rem;
      transform: translateX(400px);
      transition: all 0.3s ease;
      z-index: 1000;
      border-left: 4px solid #28a745;
    }

    .notification.show {
      transform: translateX(0);
    }

    .notification.error {
      border-left-color: #dc3545;
    }

    .notification-icon {
      font-size: 1.2rem;
    }

    @media (max-width: 768px) {
      .hero-title { font-size: 2rem; }
      .stats-overview { grid-template-columns: 1fr; }
      .quiz-grid, .attempts-grid { grid-template-columns: 1fr; }
      .user-tabs { flex-direction: column; }
      .nav-user { flex-direction: column; gap: 1rem; }
      .dashboard-content { padding: 1rem; }
    }
  `]
})
export class UserDashboardComponent implements OnInit {
  activeTab = 'quizzes';
  availableQuizzes: Quiz[] = [];
  myAttempts: QuizAttempt[] = [];
  message = '';
  isError = false;
  username = '';
  isLoading = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private quizService: QuizService
  ) {}

  ngOnInit() {
    this.username = this.authService.getUsername() || 'User';
    this.loadAvailableQuizzes();
    this.loadMyAttempts();
    
    // Check if returning from quiz completion
    this.route.queryParams.subscribe(params => {
      if (params['refresh'] === 'true') {
        this.loadMyAttempts();
        this.activeTab = 'attempts';
      }
    });
  }

  loadAvailableQuizzes() {
    this.isLoading = true;
    this.quizService.getAvailableQuizzes().subscribe({
      next: (quizzes) => {
        this.availableQuizzes = quizzes;
        this.isLoading = false;
        if (quizzes.length === 0) {
          this.showMessage('No quizzes available at the moment');
        }
      },
      error: (error) => {
        console.error('Error loading quizzes:', error);
        this.showMessage('Failed to load quizzes. Please refresh the page.', true);
        this.isLoading = false;
      }
    });
  }

  loadMyAttempts() {
    this.quizService.getUserAttempts().subscribe({
      next: (attempts) => this.myAttempts = attempts,
      error: (error) => this.showMessage('Failed to load attempts', true)
    });
  }

  startQuiz(quiz: Quiz) {
    if (!quiz || !quiz.id) {
      this.showMessage('Invalid quiz selected', true);
      return;
    }
    this.router.navigate(['/quiz', quiz.id]);
  }



  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleString();
  }

  showMessage(msg: string, error = false) {
    this.message = msg;
    this.isError = error;
    setTimeout(() => this.message = '', 5000);
  }



  viewProfile() {
    this.router.navigate(['/profile']);
  }

  getDifficulty(quiz: any): string {
    const timeLimit = quiz.timeLimit || 15;
    if (timeLimit <= 10) return 'Easy';
    if (timeLimit <= 20) return 'Medium';
    return 'Hard';
  }

  getQuestionCount(quiz: any): number {
    if (!quiz || !quiz.id) return 0;
    // Use quiz ID to generate consistent count
    return (quiz.id % 10) + 5;
  }

  getAverageScore(): number {
    if (this.myAttempts.length === 0) return 0;
    const total = this.myAttempts.reduce((sum, attempt) => sum + (attempt.percentage || 0), 0);
    return Math.round(total / this.myAttempts.length);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/home']);
  }
}
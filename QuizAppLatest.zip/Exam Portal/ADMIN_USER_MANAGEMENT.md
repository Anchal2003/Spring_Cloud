# Admin User Management Implementation

## Overview
This implementation adds admin functionality to view all users and update their roles in the quiz application.

## Backend Changes

### 1. AuthController.java
- Added two new admin endpoints:
  - `GET /auth/admin/users` - Get all users (admin only)
  - `PUT /auth/admin/users/{userId}/role` - Update user role (admin only)

### 2. AuthService.java
- Added `getAllUsers()` method with admin role validation
- Added `updateUserRole()` method with admin role validation
- Added `convertToUserProfileDto()` helper method

### 3. UpdateRoleRequest.java (New DTO)
- Simple DTO for role update requests
- Contains single `role` field

## Frontend Changes

### 1. AuthService.ts
- Already had the required methods:
  - `getAllUsers()` - Calls the admin users endpoint
  - `updateUserRole()` - Calls the role update endpoint

### 2. AdminUsersComponent.ts (New Component)
- Dedicated component for detailed user management
- Features:
  - Table view of all users with their details
  - Inline role editing with dropdown
  - Real-time role updates
  - Loading states and error handling
  - Responsive design

### 3. App Routes
- Added route: `/admin-users` protected by `AdminGuard`

### 4. AdminDashboardComponent.ts
- Added navigation button to detailed user management
- Existing user management tab remains for quick overview

## API Endpoints

### Get All Users
```
GET /auth/admin/users
Headers: 
  - Authorization: Bearer {token}
  - X-Username: {admin-username}
Response: UserProfile[]
```

### Update User Role
```
PUT /auth/admin/users/{userId}/role
Headers: 
  - Authorization: Bearer {token}
  - X-Username: {admin-username}
Body: { "role": "USER" | "ADMIN" }
Response: UserProfile
```

## Security
- Both endpoints validate that the requesting user has ADMIN role
- Returns 403 Forbidden if user is not admin
- Uses existing JWT authentication

## Usage

### For Admins:
1. Login with admin credentials
2. Navigate to Admin Dashboard
3. Click "Users" tab for quick overview
4. Click "Detailed User Management" for full table view
5. Use dropdown to change user roles
6. Changes are applied immediately

### Testing:
- Use the provided `admin-api-test.html` file to test API endpoints
- Ensure you have an admin user in the database
- Test both successful and unauthorized scenarios

## Files Modified/Created:

### Backend:
- `AuthController.java` - Added admin endpoints
- `AuthService.java` - Added admin methods
- `UpdateRoleRequest.java` - New DTO

### Frontend:
- `admin-users/admin-users.component.ts` - New component
- `app.routes.ts` - Added new route
- `admin-dashboard.component.ts` - Added navigation button

### Testing:
- `admin-api-test.html` - API testing tool

## Features:
✅ View all users with complete details
✅ Update user roles (USER ↔ ADMIN)
✅ Admin-only access with proper validation
✅ Responsive design for mobile/desktop
✅ Real-time updates without page refresh
✅ Loading states and error handling
✅ Integration with existing authentication system